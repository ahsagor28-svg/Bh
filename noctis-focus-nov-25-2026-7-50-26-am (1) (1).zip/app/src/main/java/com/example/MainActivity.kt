package com.example

import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.OrientationLock
import com.example.model.StudyMode
import com.example.model.TimerStatus
import com.example.ui.StudyScreen
import com.example.ui.StudyViewModel
import com.example.ui.theme.NoctisFocusTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            val viewModel: StudyViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val context = LocalContext.current

            // Runtime notification permission launcher for Android 13+ (Foreground Service notification)
            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) {
                viewModel.startOrResumeTimer()
            }

            // Battery Saver: only hold FLAG_KEEP_SCREEN_ON while timer is actively RUNNING
            // (never wastes battery keeping the screen awake when Idle, Paused, or Completed!)
            LaunchedEffect(uiState.prefs.keepScreenOn, uiState.timer.status) {
                if (uiState.prefs.keepScreenOn && uiState.timer.status == TimerStatus.RUNNING) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            // Ultra-low AMOLED screen brightness dim control (all the way down to 2%)
            LaunchedEffect(uiState.prefs.dimModeEnabled, uiState.prefs.dimBrightness) {
                val attrs = window.attributes
                attrs.screenBrightness = if (uiState.prefs.dimModeEnabled) {
                    uiState.prefs.dimBrightness.coerceIn(0.02f, 1.0f)
                } else {
                    WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                }
                window.attributes = attrs
            }

            // Orientation lock / quick landscape desk clock toggle
            LaunchedEffect(uiState.prefs.orientationLock) {
                requestedOrientation = when (uiState.prefs.orientationLock) {
                    OrientationLock.AUTO -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    OrientationLock.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    OrientationLock.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                }
            }

            // Immersive fullscreen Zen Mode hides system bars cleanly
            LaunchedEffect(uiState.isZenMode) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                if (uiState.isZenMode) {
                    controller.hide(WindowInsetsCompat.Type.systemBars())
                } else {
                    controller.show(WindowInsetsCompat.Type.systemBars())
                }
            }

            NoctisFocusTheme(isStopwatchMode = uiState.activeMode == StudyMode.STOPWATCH) {
                StudyScreen(
                    uiState = uiState,
                    onRequestStartOrResume = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.startOrResumeTimer()
                        }
                    },
                    onPause = viewModel::pauseTimer,
                    onReset = viewModel::resetTimer,
                    onSelectMode = viewModel::selectMode,
                    onAdd15Min = viewModel::add15Minutes,
                    onRecordLap = viewModel::recordLap,
                    onSetPomodoroDuration = viewModel::setPomodoroDuration,
                    onSetVoiceInterval = viewModel::setVoiceInterval,
                    onSetVoiceEnabled = viewModel::setVoiceEnabled,
                    onSetVoiceLanguage = viewModel::setVoiceLanguage,
                    onSetChimeEnabled = viewModel::setChimeEnabled,
                    onSetAnnounceRemaining = viewModel::setAnnounceRemaining,
                    onTestVoice = viewModel::testVoiceNow,
                    onToggleUltraBatteryMode = viewModel::toggleUltraBatteryMode,
                    onSetUltraBatteryMode = viewModel::setUltraBatteryMode,
                    onSetOledTint = viewModel::setOledTint,
                    onSetAutoZenAfterStart = viewModel::setAutoZenAfterStart,
                    onSetDimMode = viewModel::setDimModeEnabled,
                    onSetDimBrightness = viewModel::setDimBrightness,
                    onSetKeepScreenOn = viewModel::setKeepScreenOn,
                    onSetShowSeconds = viewModel::setShowSeconds,
                    onSetOrientationLock = viewModel::setOrientationLock,
                    onToggleLandscapeQuick = viewModel::toggleLandscapeQuick,
                    onSetUiLanguage = viewModel::setUiLanguage,
                    onToggleZenMode = viewModel::toggleZenMode,
                    onEnterZenMode = viewModel::enterZenMode,
                    onExitZenMode = viewModel::exitZenMode
                )
            }
        }
    }
}
