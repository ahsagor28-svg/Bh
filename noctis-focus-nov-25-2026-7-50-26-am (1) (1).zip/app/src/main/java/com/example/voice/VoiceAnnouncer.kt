package com.example.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.model.VoiceLanguage
import com.example.service.TimerStateHolder
import java.util.Locale
import java.util.UUID

class VoiceAnnouncer(context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var isBengaliSupported = false
    private var pendingSpeech: PendingSpeech? = null
    private var focusRequest: AudioFocusRequest? = null

    private data class PendingSpeech(
        val text: String,
        val language: VoiceLanguage,
        val playChime: Boolean
    )

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isInitialized = true
                    configureTts()
                    checkBengaliSupport()
                    pendingSpeech?.let { speech ->
                        pendingSpeech = null
                        speakNow(speech.text, speech.language, speech.playChime)
                    }
                } else {
                    Log.w(TAG, "TextToSpeech initialization failed with status=$status")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating TextToSpeech instance", e)
        }
    }

    private fun configureTts() {
        val engine = tts ?: return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        engine.setAudioAttributes(attrs)
        engine.setSpeechRate(0.95f)
        engine.setPitch(1.0f)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                abandonAudioFocus()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                abandonAudioFocus()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                abandonAudioFocus()
            }
        })
    }

    private fun checkBengaliSupport() {
        val engine = tts ?: return
        val bdAvail = engine.isLanguageAvailable(Locale("bn", "BD"))
        val inAvail = engine.isLanguageAvailable(Locale("bn", "IN"))
        val genericAvail = engine.isLanguageAvailable(Locale("bn"))
        isBengaliSupported =
            bdAvail >= TextToSpeech.LANG_AVAILABLE ||
                inAvail >= TextToSpeech.LANG_AVAILABLE ||
                genericAvail >= TextToSpeech.LANG_AVAILABLE
        TimerStateHolder.setBengaliTtsAvailable(isBengaliSupported)
    }

    fun announceElapsedMilestone(
        elapsedMinutes: Int,
        remainingMinutes: Int?,
        language: VoiceLanguage,
        playChime: Boolean,
        announceRemaining: Boolean
    ): String {
        val useBengali = language == VoiceLanguage.BENGALI && isBengaliSupported
        val message = if (useBengali) {
            buildBengaliElapsedPhrase(elapsedMinutes, if (announceRemaining) remainingMinutes else null)
        } else {
            buildEnglishElapsedPhrase(elapsedMinutes, if (announceRemaining) remainingMinutes else null)
        }
        speak(message, if (useBengali) VoiceLanguage.BENGALI else VoiceLanguage.ENGLISH, playChime)
        vibrateSubtle(longPulse = false)
        return message
    }

    fun announceSessionComplete(
        totalMinutes: Int,
        language: VoiceLanguage,
        playChime: Boolean
    ): String {
        val useBengali = language == VoiceLanguage.BENGALI && isBengaliSupported
        val message = if (useBengali) {
            val dur = formatBengaliDuration(totalMinutes)
            "$dur পড়াশোনার সময় শেষ হয়েছে। দারুণ কাজ করেছো!"
        } else {
            val dur = formatEnglishDuration(totalMinutes)
            "Study session of $dur complete. Great focus!"
        }
        speak(message, if (useBengali) VoiceLanguage.BENGALI else VoiceLanguage.ENGLISH, playChime)
        vibrateSubtle(longPulse = true)
        return message
    }

    fun speakTest(language: VoiceLanguage, intervalMinutes: Int, playChime: Boolean): String {
        val sampleMinutes = intervalMinutes.coerceAtLeast(1)
        val useBengali = language == VoiceLanguage.BENGALI && isBengaliSupported
        val message = if (useBengali) {
            "ভয়েস অ্যালার্ট চালু আছে। ${formatBengaliDuration(sampleMinutes)} পার হয়েছে।"
        } else {
            "Voice alert is active. ${formatEnglishDuration(sampleMinutes)} passed."
        }
        speak(message, if (useBengali) VoiceLanguage.BENGALI else VoiceLanguage.ENGLISH, playChime)
        return message
    }

    private fun speak(text: String, language: VoiceLanguage, playChime: Boolean) {
        if (!isInitialized) {
            pendingSpeech = PendingSpeech(text, language, playChime)
            return
        }
        speakNow(text, language, playChime)
    }

    private fun speakNow(text: String, language: VoiceLanguage, playChime: Boolean) {
        val engine = tts ?: return
        requestAudioFocus()

        val targetLocale = when (language) {
            VoiceLanguage.BENGALI -> selectBestBengaliLocale(engine)
            VoiceLanguage.ENGLISH -> Locale.US
        }
        engine.language = targetLocale

        val delayMs = if (playChime) {
            playGentleChime()
            340L
        } else {
            0L
        }

        mainHandler.postDelayed({
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.95f)
            }
            val utteranceId = UUID.randomUUID().toString()
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }, delayMs)
    }

    private fun selectBestBengaliLocale(engine: TextToSpeech): Locale {
        val candidates = listOf(Locale("bn", "BD"), Locale("bn", "IN"), Locale("bn"))
        for (locale in candidates) {
            if (engine.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE) {
                return locale
            }
        }
        return Locale.US
    }

    private fun playGentleChime() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 45)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 180)
            mainHandler.postDelayed({
                runCatching { tone.release() }
            }, 300L)
        } catch (e: Exception) {
            Log.w(TAG, "Unable to play subtle chime", e)
        }
    }

    private fun vibrateSubtle(longPulse: Boolean) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return

            if (!vibrator.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = if (longPulse) {
                    VibrationEffect.createWaveform(longArrayOf(0, 180, 120, 260), -1)
                } else {
                    VibrationEffect.createOneShot(90, 90)
                }
                vibrator.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (longPulse) 280L else 90L)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibration unavailable", e)
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
            focusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    fun release() {
        mainHandler.removeCallbacksAndMessages(null)
        abandonAudioFocus()
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        isInitialized = false
    }

    companion object {
        private const val TAG = "VoiceAnnouncer"

        fun formatBengaliDuration(totalMinutes: Int): String {
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            return when {
                hours > 0 && minutes > 0 -> "$hours ঘণ্টা $minutes মিনিট"
                hours > 0 -> "$hours ঘণ্টা"
                else -> "$minutes মিনিট"
            }
        }

        fun formatEnglishDuration(totalMinutes: Int): String {
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            val hPart = if (hours == 1) "1 hour" else "$hours hours"
            val mPart = if (minutes == 1) "1 minute" else "$minutes minutes"
            return when {
                hours > 0 && minutes > 0 -> "$hPart and $mPart"
                hours > 0 -> hPart
                else -> mPart
            }
        }

        fun buildBengaliElapsedPhrase(elapsedMinutes: Int, remainingMinutes: Int?): String {
            val elapsedPart = "${formatBengaliDuration(elapsedMinutes)} পার হয়েছে।"
            return if (remainingMinutes != null && remainingMinutes > 0) {
                "$elapsedPart বাকি আছে ${formatBengaliDuration(remainingMinutes)}।"
            } else {
                elapsedPart
            }
        }

        fun buildEnglishElapsedPhrase(elapsedMinutes: Int, remainingMinutes: Int?): String {
            val elapsedPart = "${formatEnglishDuration(elapsedMinutes)} passed."
            return if (remainingMinutes != null && remainingMinutes > 0) {
                "$elapsedPart ${formatEnglishDuration(remainingMinutes)} remaining."
            } else {
                elapsedPart
            }
        }
    }
}
