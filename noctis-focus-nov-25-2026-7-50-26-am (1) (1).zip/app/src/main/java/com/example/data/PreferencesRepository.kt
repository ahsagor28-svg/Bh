package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.OledTint
import com.example.model.OrientationLock
import com.example.model.StudyMode
import com.example.model.UiLanguage
import com.example.model.UserPreferences
import com.example.model.VoiceLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Context.studyDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "noctis_focus_prefs"
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val MODE = stringPreferencesKey("mode")
        val POMODORO_DURATION_MIN = intPreferencesKey("pomodoro_duration_min")
        val POMODORO_VOICE_INTERVAL_MIN = intPreferencesKey("pomodoro_voice_interval_min")
        val STOPWATCH_VOICE_INTERVAL_MIN = intPreferencesKey("stopwatch_voice_interval_min")
        val VOICE_ENABLED = booleanPreferencesKey("voice_enabled")
        val CHIME_ENABLED = booleanPreferencesKey("chime_enabled")
        val ANNOUNCE_REMAINING = booleanPreferencesKey("announce_remaining")
        val VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        val UI_LANGUAGE = stringPreferencesKey("ui_language")
        val ULTRA_BATTERY_MODE = booleanPreferencesKey("ultra_battery_mode")
        val OLED_TINT = stringPreferencesKey("oled_tint")
        val AUTO_ZEN_AFTER_START = booleanPreferencesKey("auto_zen_after_start")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val DIM_MODE_ENABLED = booleanPreferencesKey("dim_mode_enabled")
        val DIM_BRIGHTNESS = floatPreferencesKey("dim_brightness")
        val SHOW_SECONDS = booleanPreferencesKey("show_seconds")
        val ORIENTATION_LOCK = stringPreferencesKey("orientation_lock")
        val TODAY_STUDY_SECONDS = longPreferencesKey("today_study_seconds")
        val TODAY_DATE_KEY = stringPreferencesKey("today_date_key")
    }

    private fun currentDateKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    val preferencesFlow: Flow<UserPreferences> = context.studyDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            val todayKey = currentDateKey()
            val savedDateKey = prefs[Keys.TODAY_DATE_KEY] ?: todayKey
            val todaySeconds = if (savedDateKey == todayKey) {
                prefs[Keys.TODAY_STUDY_SECONDS] ?: 0L
            } else {
                0L
            }

            UserPreferences(
                mode = prefs[Keys.MODE]?.let { runCatching { StudyMode.valueOf(it) }.getOrNull() }
                    ?: StudyMode.POMODORO,
                pomodoroDurationMinutes = (prefs[Keys.POMODORO_DURATION_MIN] ?: 120).coerceIn(1, 720),
                pomodoroVoiceIntervalMinutes = (prefs[Keys.POMODORO_VOICE_INTERVAL_MIN] ?: 20).coerceIn(0, 180),
                stopwatchVoiceIntervalMinutes = (prefs[Keys.STOPWATCH_VOICE_INTERVAL_MIN] ?: 20).coerceIn(0, 180),
                voiceEnabled = prefs[Keys.VOICE_ENABLED] ?: true,
                chimeEnabled = prefs[Keys.CHIME_ENABLED] ?: true,
                announceRemainingInPomodoro = prefs[Keys.ANNOUNCE_REMAINING] ?: false,
                voiceLanguage = prefs[Keys.VOICE_LANGUAGE]?.let {
                    runCatching { VoiceLanguage.valueOf(it) }.getOrNull()
                } ?: VoiceLanguage.BENGALI,
                uiLanguage = prefs[Keys.UI_LANGUAGE]?.let {
                    runCatching { UiLanguage.valueOf(it) }.getOrNull()
                } ?: UiLanguage.BENGALI,
                ultraBatteryMode = prefs[Keys.ULTRA_BATTERY_MODE] ?: true,
                oledTint = prefs[Keys.OLED_TINT]?.let {
                    runCatching { OledTint.valueOf(it) }.getOrNull()
                } ?: OledTint.WARM_AMBER,
                autoZenAfterStart = prefs[Keys.AUTO_ZEN_AFTER_START] ?: true,
                keepScreenOn = prefs[Keys.KEEP_SCREEN_ON] ?: true,
                dimModeEnabled = prefs[Keys.DIM_MODE_ENABLED] ?: true,
                dimBrightness = (prefs[Keys.DIM_BRIGHTNESS] ?: 0.20f).coerceIn(0.02f, 1.0f),
                showSeconds = prefs[Keys.SHOW_SECONDS] ?: false,
                orientationLock = prefs[Keys.ORIENTATION_LOCK]?.let {
                    runCatching { OrientationLock.valueOf(it) }.getOrNull()
                } ?: OrientationLock.AUTO,
                todayStudySeconds = todaySeconds,
                todayDateKey = todayKey
            )
        }

    suspend fun setMode(mode: StudyMode) {
        context.studyDataStore.edit { it[Keys.MODE] = mode.name }
    }

    suspend fun setPomodoroDuration(minutes: Int) {
        context.studyDataStore.edit {
            it[Keys.POMODORO_DURATION_MIN] = minutes.coerceIn(1, 720)
        }
    }

    suspend fun setVoiceInterval(mode: StudyMode, minutes: Int) {
        context.studyDataStore.edit {
            val clamped = minutes.coerceIn(0, 180)
            if (mode == StudyMode.POMODORO) {
                it[Keys.POMODORO_VOICE_INTERVAL_MIN] = clamped
            } else {
                it[Keys.STOPWATCH_VOICE_INTERVAL_MIN] = clamped
            }
            if (clamped > 0) {
                it[Keys.VOICE_ENABLED] = true
            }
        }
    }

    suspend fun setVoiceEnabled(enabled: Boolean) {
        context.studyDataStore.edit { it[Keys.VOICE_ENABLED] = enabled }
    }

    suspend fun setChimeEnabled(enabled: Boolean) {
        context.studyDataStore.edit { it[Keys.CHIME_ENABLED] = enabled }
    }

    suspend fun setAnnounceRemaining(enabled: Boolean) {
        context.studyDataStore.edit { it[Keys.ANNOUNCE_REMAINING] = enabled }
    }

    suspend fun setVoiceLanguage(language: VoiceLanguage) {
        context.studyDataStore.edit { it[Keys.VOICE_LANGUAGE] = language.name }
    }

    suspend fun setUiLanguage(language: UiLanguage) {
        context.studyDataStore.edit { it[Keys.UI_LANGUAGE] = language.name }
    }

    suspend fun setUltraBatteryMode(enabled: Boolean) {
        context.studyDataStore.edit { prefs ->
            prefs[Keys.ULTRA_BATTERY_MODE] = enabled
            if (enabled) {
                // Apply optimal OLED & CPU battery-saving configuration in one tap
                prefs[Keys.DIM_MODE_ENABLED] = true
                prefs[Keys.DIM_BRIGHTNESS] = 0.16f
                prefs[Keys.SHOW_SECONDS] = false
                prefs[Keys.AUTO_ZEN_AFTER_START] = true
                prefs[Keys.OLED_TINT] = OledTint.ULTRA_ECO_RED.name
            } else {
                // Restore high-contrast bright standard desk clock mode
                prefs[Keys.DIM_MODE_ENABLED] = false
                prefs[Keys.SHOW_SECONDS] = true
                prefs[Keys.AUTO_ZEN_AFTER_START] = false
                prefs[Keys.OLED_TINT] = OledTint.LUMINOUS_WHITE.name
            }
        }
    }

    suspend fun setOledTint(tint: OledTint) {
        context.studyDataStore.edit { it[Keys.OLED_TINT] = tint.name }
    }

    suspend fun setAutoZenAfterStart(enabled: Boolean) {
        context.studyDataStore.edit { it[Keys.AUTO_ZEN_AFTER_START] = enabled }
    }

    suspend fun setKeepScreenOn(enabled: Boolean) {
        context.studyDataStore.edit { it[Keys.KEEP_SCREEN_ON] = enabled }
    }

    suspend fun setDimModeEnabled(enabled: Boolean) {
        context.studyDataStore.edit { it[Keys.DIM_MODE_ENABLED] = enabled }
    }

    suspend fun setDimBrightness(brightness: Float) {
        context.studyDataStore.edit {
            it[Keys.DIM_BRIGHTNESS] = brightness.coerceIn(0.02f, 1.0f)
        }
    }

    suspend fun setShowSeconds(show: Boolean) {
        context.studyDataStore.edit { it[Keys.SHOW_SECONDS] = show }
    }

    suspend fun setOrientationLock(lock: OrientationLock) {
        context.studyDataStore.edit { it[Keys.ORIENTATION_LOCK] = lock.name }
    }

    suspend fun addStudySeconds(deltaSeconds: Long) {
        if (deltaSeconds <= 0L) return
        val todayKey = currentDateKey()
        context.studyDataStore.edit { prefs ->
            val savedKey = prefs[Keys.TODAY_DATE_KEY]
            val currentTotal = if (savedKey == todayKey) {
                prefs[Keys.TODAY_STUDY_SECONDS] ?: 0L
            } else {
                0L
            }
            prefs[Keys.TODAY_DATE_KEY] = todayKey
            prefs[Keys.TODAY_STUDY_SECONDS] = currentTotal + deltaSeconds
        }
    }
}
