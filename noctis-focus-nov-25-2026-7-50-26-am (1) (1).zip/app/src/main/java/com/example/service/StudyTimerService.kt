package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.PreferencesRepository
import com.example.model.StudyLap
import com.example.model.StudyMode
import com.example.model.TimerSnapshot
import com.example.model.TimerStatus
import com.example.model.UiLanguage
import com.example.model.UserPreferences
import com.example.voice.VoiceAnnouncer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class StudyTimerService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var prefsRepository: PreferencesRepository
    private lateinit var voiceAnnouncer: VoiceAnnouncer
    private lateinit var notificationManager: NotificationManager
    private lateinit var powerManager: PowerManager

    private var wakeLock: PowerManager.WakeLock? = null
    private var tickerJob: Job? = null
    private var prefsCollectorJob: Job? = null

    private var isScreenInteractive: Boolean = true
    private var screenReceiverRegistered: Boolean = false

    private var latestPrefs: UserPreferences = UserPreferences()
    private var currentMode: StudyMode = StudyMode.POMODORO
    private var status: TimerStatus = TimerStatus.IDLE
    private var targetDurationMs: Long = 120 * 60_000L
    private var accumulatedElapsedMs: Long = 0L
    private var anchorElapsedRealtimeMs: Long = 0L
    private var lastAnnouncedStep: Int = 0
    private var lastPersistedElapsedSec: Long = 0L
    private var lastNotificationBucket: Long = -1L
    private var laps: MutableList<StudyLap> = mutableListOf()
    private var lastAnnouncementText: String? = null
    private var isForegroundStarted = false

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    isScreenInteractive = false
                    if (status == TimerStatus.RUNNING) {
                        // Switch immediately to deep-sleep milestone-only scheduling
                        startTicker()
                    }
                }
                Intent.ACTION_SCREEN_ON -> {
                    isScreenInteractive = true
                    if (status == TimerStatus.RUNNING) {
                        // Immediately refresh UI/notification and switch back to display-aligned ticks
                        recomputeAndEmit(currentElapsedMs(), forceNotificationUpdate = true)
                        startTicker()
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefsRepository = PreferencesRepository(applicationContext)
        voiceAnnouncer = VoiceAnnouncer(applicationContext)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        isScreenInteractive = powerManager.isInteractive
        createNotificationChannel()
        registerScreenStateReceiver()

        prefsCollectorJob = serviceScope.launch {
            prefsRepository.preferencesFlow.collect { prefs ->
                val showSecondsChanged = latestPrefs.showSeconds != prefs.showSeconds
                val intervalChanged = latestPrefs.activeVoiceIntervalMinutes != prefs.activeVoiceIntervalMinutes ||
                    latestPrefs.voiceEnabled != prefs.voiceEnabled
                latestPrefs = prefs
                if (status == TimerStatus.RUNNING || status == TimerStatus.PAUSED) {
                    recomputeAndEmit(nowElapsedMs = currentElapsedMs(), forceNotificationUpdate = true)
                    if (status == TimerStatus.RUNNING && (showSecondsChanged || intervalChanged)) {
                        startTicker()
                    }
                }
            }
        }
    }

    private fun registerScreenStateReceiver() {
        if (screenReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            this,
            screenStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        screenReceiverRegistered = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_START_OR_RESUME -> {
                val modeName = intent.getStringExtra(EXTRA_MODE)
                val targetMinutes = intent.getIntExtra(EXTRA_TARGET_MINUTES, -1)
                serviceScope.launch {
                    latestPrefs = prefsRepository.preferencesFlow.first()
                    handleStartOrResume(
                        requestedMode = modeName?.let { runCatching { StudyMode.valueOf(it) }.getOrNull() },
                        requestedTargetMinutes = targetMinutes
                    )
                }
            }
            ACTION_PAUSE -> handlePause()
            ACTION_RESET -> handleReset()
            ACTION_ADD_15_MIN -> handleAddMinutes(15)
            ACTION_RECORD_LAP -> handleRecordLap()
            ACTION_TEST_VOICE -> {
                serviceScope.launch {
                    latestPrefs = prefsRepository.preferencesFlow.first()
                    val spoken = voiceAnnouncer.speakTest(
                        language = latestPrefs.voiceLanguage,
                        intervalMinutes = latestPrefs.activeVoiceIntervalMinutes.coerceAtLeast(1),
                        playChime = latestPrefs.chimeEnabled
                    )
                    lastAnnouncementText = spoken
                    TimerStateHolder.updateSnapshot { it.copy(lastAnnouncementText = spoken) }
                    if (status == TimerStatus.IDLE && !isForegroundStarted) {
                        delay(4500L)
                        if (status == TimerStatus.IDLE) stopSelf()
                    }
                }
            }
        }

        return START_STICKY
    }

    private fun handleStartOrResume(
        requestedMode: StudyMode?,
        requestedTargetMinutes: Int
    ) {
        if (status == TimerStatus.IDLE || status == TimerStatus.COMPLETED) {
            currentMode = requestedMode ?: latestPrefs.mode
            val minutes = if (requestedTargetMinutes > 0) {
                requestedTargetMinutes
            } else {
                latestPrefs.pomodoroDurationMinutes
            }
            targetDurationMs = minutes * 60_000L
            accumulatedElapsedMs = 0L
            lastAnnouncedStep = 0
            lastPersistedElapsedSec = 0L
            laps.clear()
            lastAnnouncementText = null
        }

        if (status == TimerStatus.RUNNING) return

        status = TimerStatus.RUNNING
        anchorElapsedRealtimeMs = SystemClock.elapsedRealtime()
        isScreenInteractive = powerManager.isInteractive
        acquireWakeLock()
        startForegroundInternal()
        recomputeAndEmit(currentElapsedMs(), forceNotificationUpdate = true)
        startTicker()
    }

    private fun handlePause() {
        if (status != TimerStatus.RUNNING) return
        accumulatedElapsedMs = currentElapsedMs()
        status = TimerStatus.PAUSED
        tickerJob?.cancel()
        tickerJob = null
        persistUncommittedStudySeconds(accumulatedElapsedMs)
        releaseWakeLock()
        recomputeAndEmit(accumulatedElapsedMs, forceNotificationUpdate = true)
    }

    private fun handleReset() {
        val elapsed = currentElapsedMs()
        if (elapsed > 0L) {
            persistUncommittedStudySeconds(elapsed)
        }
        tickerJob?.cancel()
        tickerJob = null
        releaseWakeLock()

        status = TimerStatus.IDLE
        accumulatedElapsedMs = 0L
        anchorElapsedRealtimeMs = 0L
        lastAnnouncedStep = 0
        lastPersistedElapsedSec = 0L
        lastNotificationBucket = -1L
        laps.clear()
        lastAnnouncementText = null

        val targetMs = latestPrefs.pomodoroDurationMinutes * 60_000L
        targetDurationMs = targetMs
        val interval = latestPrefs.activeVoiceIntervalMinutes

        TimerStateHolder.updateSnapshot {
            TimerSnapshot(
                mode = latestPrefs.mode,
                status = TimerStatus.IDLE,
                targetDurationMs = targetMs,
                elapsedMs = 0L,
                remainingMs = targetMs,
                voiceIntervalMinutes = interval,
                voiceEnabled = latestPrefs.voiceEnabled,
                lastAnnouncedStep = 0,
                nextAnnouncementInMs = if (latestPrefs.voiceEnabled && interval > 0) {
                    interval * 60_000L
                } else null,
                laps = emptyList(),
                lastAnnouncementText = null
            )
        }

        stopForegroundAndSelf()
    }

    private fun handleAddMinutes(extraMinutes: Int) {
        if (currentMode != StudyMode.POMODORO) return
        val extraMs = extraMinutes * 60_000L
        targetDurationMs = (targetDurationMs + extraMs).coerceAtMost(12 * 3600_000L)
        if (status == TimerStatus.COMPLETED) {
            status = TimerStatus.PAUSED
        }
        recomputeAndEmit(currentElapsedMs(), forceNotificationUpdate = true)
        if (status == TimerStatus.RUNNING) {
            startTicker()
        }
    }

    private fun handleRecordLap() {
        if (currentMode != StudyMode.STOPWATCH || status == TimerStatus.IDLE) return
        val total = currentElapsedMs()
        val prevTotal = laps.firstOrNull()?.totalElapsedMs ?: 0L
        val split = (total - prevTotal).coerceAtLeast(0L)
        val lap = StudyLap(
            index = laps.size + 1,
            totalElapsedMs = total,
            splitMs = split
        )
        laps.add(0, lap)
        recomputeAndEmit(total, forceNotificationUpdate = false)
    }

    /**
     * Ultra battery-efficient adaptive scheduler:
     * - Screen OFF: sleeps directly until the exact next voice milestone or Pomodoro completion
     *   (typically ~3 wakeups/hour instead of 18,000/hour!).
     * - Screen ON + Minute-only Eco mode: sleeps until the exact next minute boundary (1 redraw/min),
     *   switching to 1-second ticks only during the final 60s of a Pomodoro.
     * - Screen ON + Seconds visible: aligns cleanly to exact 1-second boundaries (5x fewer wakeups than 200ms).
     */
    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = serviceScope.launch {
            while (isActive && status == TimerStatus.RUNNING) {
                val elapsed = currentElapsedMs()

                // 1. Check Pomodoro completion
                if (currentMode == StudyMode.POMODORO && elapsed >= targetDurationMs) {
                    handlePomodoroCompleted()
                    break
                }

                // 2. Check Voice Announcement Milestone
                val announcedNow = checkVoiceMilestone(elapsed)

                // 3. Periodically commit study seconds (every 60s or on milestone)
                val elapsedSec = elapsed / 1000L
                if (announcedNow || elapsedSec - lastPersistedElapsedSec >= 60L) {
                    persistUncommittedStudySeconds(elapsed)
                }

                // 4. Emit UI update & refresh notification (never spam notification when screen is off)
                recomputeAndEmit(
                    nowElapsedMs = elapsed,
                    forceNotificationUpdate = announcedNow
                )

                // 5. Compute optimal battery-saving sleep duration until next required wakeup
                val sleepMs = computeNextWakeDelayMs(elapsed)
                delay(sleepMs)
            }
        }
    }

    private fun computeNextWakeDelayMs(elapsedMs: Long): Long {
        val remainingMs = if (currentMode == StudyMode.POMODORO) {
            (targetDurationMs - elapsedMs).coerceAtLeast(0L)
        } else {
            Long.MAX_VALUE
        }

        val intervalMinutes = activeIntervalMinutes()
        val msUntilVoice = if (latestPrefs.voiceEnabled && intervalMinutes > 0) {
            val nextTargetMs = (lastAnnouncedStep + 1) * intervalMinutes * 60_000L
            (nextTargetMs - elapsedMs).coerceAtLeast(50L)
        } else {
            Long.MAX_VALUE
        }

        // Next mandatory event (either voice alert or Pomodoro end)
        val nextEventMs = minOf(remainingMs, msUntilVoice)

        if (!isScreenInteractive) {
            // Screen is OFF: sleep cleanly until the exact next voice alert or completion!
            // Cap at 5 minutes only when no event is scheduled (e.g. Stopwatch with voice OFF)
            // so study progress is periodically persisted.
            val fallbackCap = 5 * 60_000L
            val targetWait = if (nextEventMs == Long.MAX_VALUE) fallbackCap else nextEventMs
            return targetWait.coerceAtLeast(100L)
        }

        // Screen is ON: align wakeups cleanly to visible clock precision
        val inFinalPomodoroMinute = currentMode == StudyMode.POMODORO && remainingMs <= 60_000L
        val needsSecondTicks = latestPrefs.showSeconds || inFinalPomodoroMinute

        val uiWaitMs = if (needsSecondTicks) {
            val msToNextSecond = if (currentMode == StudyMode.POMODORO) {
                val remMod = remainingMs % 1000L
                if (remMod == 0L) 1000L else remMod
            } else {
                1000L - (elapsedMs % 1000L)
            }
            (msToNextSecond + 15L).coerceIn(100L, 1020L)
        } else {
            // Minute-only Eco Mode: 1 single UI redraw per minute!
            val msToNextMinute = if (currentMode == StudyMode.POMODORO) {
                val remMod = remainingMs % 60_000L
                if (remMod == 0L) 60_000L else remMod
            } else {
                60_000L - (elapsedMs % 60_000L)
            }
            (msToNextMinute + 25L).coerceIn(250L, 60_050L)
        }

        return minOf(uiWaitMs, nextEventMs).coerceAtLeast(100L)
    }

    private fun activeIntervalMinutes(): Int {
        return if (currentMode == StudyMode.POMODORO) {
            latestPrefs.pomodoroVoiceIntervalMinutes
        } else {
            latestPrefs.stopwatchVoiceIntervalMinutes
        }
    }

    private fun checkVoiceMilestone(elapsedMs: Long): Boolean {
        val intervalMinutes = activeIntervalMinutes()
        if (!latestPrefs.voiceEnabled || intervalMinutes <= 0) return false

        val intervalMs = intervalMinutes * 60_000L
        val currentStep = (elapsedMs / intervalMs).toInt()
        if (currentStep > lastAnnouncedStep && currentStep >= 1) {
            lastAnnouncedStep = currentStep
            val elapsedMinutes = currentStep * intervalMinutes
            val remainingMinutes = if (currentMode == StudyMode.POMODORO) {
                ((targetDurationMs - elapsedMs).coerceAtLeast(0L) / 60_000L).toInt()
            } else {
                null
            }
            val spoken = voiceAnnouncer.announceElapsedMilestone(
                elapsedMinutes = elapsedMinutes,
                remainingMinutes = remainingMinutes,
                language = latestPrefs.voiceLanguage,
                playChime = latestPrefs.chimeEnabled,
                announceRemaining = latestPrefs.announceRemainingInPomodoro && currentMode == StudyMode.POMODORO
            )
            lastAnnouncementText = spoken
            return true
        }
        return false
    }

    private fun handlePomodoroCompleted() {
        accumulatedElapsedMs = targetDurationMs
        status = TimerStatus.COMPLETED
        tickerJob?.cancel()
        tickerJob = null
        persistUncommittedStudySeconds(targetDurationMs)
        releaseWakeLock()

        val totalMinutes = (targetDurationMs / 60_000L).toInt().coerceAtLeast(1)
        if (latestPrefs.voiceEnabled) {
            lastAnnouncementText = voiceAnnouncer.announceSessionComplete(
                totalMinutes = totalMinutes,
                language = latestPrefs.voiceLanguage,
                playChime = latestPrefs.chimeEnabled
            )
        }

        recomputeAndEmit(targetDurationMs, forceNotificationUpdate = true)
    }

    private fun currentElapsedMs(): Long {
        return when (status) {
            TimerStatus.RUNNING -> accumulatedElapsedMs + (SystemClock.elapsedRealtime() - anchorElapsedRealtimeMs)
            else -> accumulatedElapsedMs
        }
    }

    private fun persistUncommittedStudySeconds(elapsedMs: Long) {
        val elapsedSec = elapsedMs / 1000L
        val delta = elapsedSec - lastPersistedElapsedSec
        if (delta > 0L) {
            lastPersistedElapsedSec = elapsedSec
            serviceScope.launch {
                prefsRepository.addStudySeconds(delta)
            }
        }
    }

    private fun recomputeAndEmit(nowElapsedMs: Long, forceNotificationUpdate: Boolean) {
        val remaining = if (currentMode == StudyMode.POMODORO) {
            (targetDurationMs - nowElapsedMs).coerceAtLeast(0L)
        } else {
            0L
        }
        val intervalMinutes = activeIntervalMinutes()

        val nextAnnouncementInMs = if (latestPrefs.voiceEnabled && intervalMinutes > 0 && status != TimerStatus.COMPLETED) {
            val intervalMs = intervalMinutes * 60_000L
            val nextTargetMs = (lastAnnouncedStep + 1) * intervalMs
            val diff = (nextTargetMs - nowElapsedMs).coerceAtLeast(0L)
            if (currentMode == StudyMode.POMODORO && nextTargetMs >= targetDurationMs) {
                null
            } else {
                diff
            }
        } else {
            null
        }

        val snapshot = TimerSnapshot(
            mode = currentMode,
            status = status,
            targetDurationMs = targetDurationMs,
            elapsedMs = nowElapsedMs,
            remainingMs = remaining,
            voiceIntervalMinutes = intervalMinutes,
            voiceEnabled = latestPrefs.voiceEnabled,
            lastAnnouncedStep = lastAnnouncedStep,
            nextAnnouncementInMs = nextAnnouncementInMs,
            laps = laps.toList(),
            lastAnnouncementText = lastAnnouncementText
        )
        TimerStateHolder.updateSnapshot { snapshot }

        if (isForegroundStarted) {
            // Battery Saver: only update notification once per minute in Eco mode (or once/sec if seconds visible),
            // and never wake SystemUI with periodic notification refreshes while screen is OFF.
            val bucketSizeMs = if (latestPrefs.showSeconds && !latestPrefs.ultraBatteryMode) 1000L else 60_000L
            val bucket = nowElapsedMs / bucketSizeMs
            val shouldNotify = forceNotificationUpdate || (isScreenInteractive && bucket != lastNotificationBucket)
            if (shouldNotify) {
                lastNotificationBucket = bucket
                notificationManager.notify(NOTIFICATION_ID, buildNotification(snapshot))
            }
        }
    }

    private fun startForegroundInternal() {
        val notification = buildNotification(TimerStateHolder.snapshot.value)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        isForegroundStarted = true
    }

    private fun stopForegroundAndSelf() {
        if (isForegroundStarted) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            isForegroundStarted = false
        }
        stopSelf()
    }

    private fun buildNotification(snapshot: TimerSnapshot): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val isBn = latestPrefs.uiLanguage == UiLanguage.BENGALI
        val showSec = latestPrefs.showSeconds && !latestPrefs.ultraBatteryMode
        val modeLabel = when (snapshot.mode) {
            StudyMode.POMODORO -> if (isBn) "পোমোডোরো" else "Pomodoro"
            StudyMode.STOPWATCH -> if (isBn) "স্টপওয়াচ" else "Stopwatch"
        }

        val formattedTime = when (snapshot.mode) {
            StudyMode.POMODORO -> TimerStateHolder.formatClock(snapshot.remainingMs, showSeconds = showSec)
            StudyMode.STOPWATCH -> TimerStateHolder.formatStopwatchClock(snapshot.elapsedMs, showSeconds = showSec)
        }

        val statusSuffix = when (snapshot.status) {
            TimerStatus.RUNNING -> ""
            TimerStatus.PAUSED -> if (isBn) " (বিরতি)" else " (Paused)"
            TimerStatus.COMPLETED -> if (isBn) " (সম্পূর্ণ)" else " (Done)"
            TimerStatus.IDLE -> ""
        }

        val contentText = buildString {
            if (snapshot.status == TimerStatus.COMPLETED) {
                append(if (isBn) "পড়াশোনার সেশন সম্পন্ন হয়েছে!" else "Study session complete!")
            } else if (snapshot.voiceEnabled && snapshot.voiceIntervalMinutes > 0) {
                if (isBn) {
                    append("ভয়েস অ্যালার্ট: প্রতি ${snapshot.voiceIntervalMinutes} মি.")
                } else {
                    append("Voice alert every ${snapshot.voiceIntervalMinutes}m")
                }
                if (showSec) {
                    snapshot.nextAnnouncementInMs?.let { nextMs ->
                        val nextStr = TimerStateHolder.formatCountdownCompact(nextMs)
                        append(if (isBn) " • বাকি $nextStr" else " • Next in $nextStr")
                    }
                }
            } else {
                append(if (isBn) "ভয়েস অ্যালার্ট বন্ধ" else "Voice alerts off")
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("$modeLabel • $formattedTime$statusSuffix")
            .setContentText(contentText)
            .setContentIntent(openAppIntent)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setOngoing(snapshot.status == TimerStatus.RUNNING || snapshot.status == TimerStatus.PAUSED)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (snapshot.status == TimerStatus.RUNNING) {
            builder.addAction(
                0,
                if (isBn) "বিরতি" else getString(R.string.action_pause),
                servicePendingIntent(ACTION_PAUSE, 1)
            )
        } else if (snapshot.status == TimerStatus.PAUSED) {
            builder.addAction(
                0,
                if (isBn) "চালু" else getString(R.string.action_resume),
                servicePendingIntent(ACTION_START_OR_RESUME, 2)
            )
        }

        builder.addAction(
            0,
            if (isBn) "রিসেট" else getString(R.string.action_reset),
            servicePendingIntent(ACTION_RESET, 3)
        )

        return builder.build()
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, StudyTimerService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "NoctisFocus:StudyTimerWakeLock"
        ).apply {
            setReferenceCounted(false)
            // Safety cap of 14 hours; always released early on pause/reset/complete/destroy
            acquire(14 * 3600_000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
        wakeLock = null
    }

    override fun onDestroy() {
        val elapsed = currentElapsedMs()
        if (elapsed > 0L && status == TimerStatus.RUNNING) {
            persistUncommittedStudySeconds(elapsed)
        }
        if (screenReceiverRegistered) {
            runCatching { unregisterReceiver(screenStateReceiver) }
            screenReceiverRegistered = false
        }
        tickerJob?.cancel()
        prefsCollectorJob?.cancel()
        releaseWakeLock()
        voiceAnnouncer.release()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "noctis_study_timer_channel"
        const val NOTIFICATION_ID = 4021

        const val ACTION_START_OR_RESUME = "com.example.action.START_OR_RESUME"
        const val ACTION_PAUSE = "com.example.action.PAUSE"
        const val ACTION_RESET = "com.example.action.RESET"
        const val ACTION_ADD_15_MIN = "com.example.action.ADD_15_MIN"
        const val ACTION_RECORD_LAP = "com.example.action.RECORD_LAP"
        const val ACTION_TEST_VOICE = "com.example.action.TEST_VOICE"

        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_TARGET_MINUTES = "extra_target_minutes"
    }
}
