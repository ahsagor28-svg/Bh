package com.example.service

import com.example.model.StudyMode
import com.example.model.TimerSnapshot
import com.example.model.TimerStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

object TimerStateHolder {
    private val _snapshot = MutableStateFlow(TimerSnapshot())
    val snapshot: StateFlow<TimerSnapshot> = _snapshot.asStateFlow()

    private val _bengaliTtsAvailable = MutableStateFlow<Boolean?>(null)
    val bengaliTtsAvailable: StateFlow<Boolean?> = _bengaliTtsAvailable.asStateFlow()

    fun updateSnapshot(transform: (TimerSnapshot) -> TimerSnapshot) {
        _snapshot.update(transform)
    }

    fun setBengaliTtsAvailable(available: Boolean) {
        _bengaliTtsAvailable.value = available
    }

    fun syncIdleConfig(
        mode: StudyMode,
        pomodoroDurationMinutes: Int,
        voiceIntervalMinutes: Int,
        voiceEnabled: Boolean
    ) {
        _snapshot.update { current ->
            if (current.status == TimerStatus.IDLE) {
                val targetMs = pomodoroDurationMinutes * 60_000L
                current.copy(
                    mode = mode,
                    targetDurationMs = targetMs,
                    elapsedMs = 0L,
                    remainingMs = targetMs,
                    voiceIntervalMinutes = voiceIntervalMinutes,
                    voiceEnabled = voiceEnabled,
                    lastAnnouncedStep = 0,
                    nextAnnouncementInMs = if (voiceEnabled && voiceIntervalMinutes > 0) {
                        voiceIntervalMinutes * 60_000L
                    } else null,
                    laps = emptyList()
                )
            } else {
                current.copy(
                    voiceIntervalMinutes = voiceIntervalMinutes,
                    voiceEnabled = voiceEnabled
                )
            }
        }
    }

    fun formatClock(ms: Long, showSeconds: Boolean = true, forceHours: Boolean = false): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSeconds = (safeMs + 999L) / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L

        return when {
            hours > 0L || forceHours -> {
                if (showSeconds) {
                    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
                } else {
                    String.format(Locale.US, "%02d:%02d", hours, minutes)
                }
            }
            else -> {
                if (showSeconds) {
                    String.format(Locale.US, "%02d:%02d", minutes, seconds)
                } else {
                    String.format(Locale.US, "00:%02d", minutes)
                }
            }
        }
    }

    fun formatStopwatchClock(ms: Long, showSeconds: Boolean = true): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSeconds = safeMs / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L

        return when {
            hours > 0L -> {
                if (showSeconds) {
                    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
                } else {
                    String.format(Locale.US, "%02d:%02d", hours, minutes)
                }
            }
            else -> {
                if (showSeconds) {
                    String.format(Locale.US, "%02d:%02d", minutes, seconds)
                } else {
                    String.format(Locale.US, "00:%02d", minutes)
                }
            }
        }
    }

    fun formatCountdownCompact(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSeconds = (safeMs + 999L) / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatDurationLabel(totalMinutes: Int, isBengali: Boolean): String {
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return if (isBengali) {
            when {
                h > 0 && m > 0 -> "${h} ঘ. ${m} মি."
                h > 0 -> "${h} ঘণ্টা"
                else -> "${m} মিনিট"
            }
        } else {
            when {
                h > 0 && m > 0 -> "${h}h ${m}m"
                h > 0 -> "${h}h"
                else -> "${m}m"
            }
        }
    }

    fun formatTodayStudy(totalSeconds: Long, isBengali: Boolean): String {
        val totalMinutes = (totalSeconds / 60L).toInt()
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return if (isBengali) {
            when {
                h > 0 && m > 0 -> "${h} ঘ. ${m} মি."
                h > 0 -> "${h} ঘণ্টা"
                m > 0 -> "${m} মিনিট"
                else -> "0 মিনিট"
            }
        } else {
            when {
                h > 0 && m > 0 -> "${h}h ${m}m"
                h > 0 -> "${h}h"
                m > 0 -> "${m}m"
                else -> "0m"
            }
        }
    }
}
