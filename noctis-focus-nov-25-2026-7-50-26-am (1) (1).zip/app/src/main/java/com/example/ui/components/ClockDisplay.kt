package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OledTint
import com.example.model.StudyMode
import com.example.model.TimerSnapshot
import com.example.model.TimerStatus
import com.example.service.TimerStateHolder
import com.example.ui.StudyStrings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.MutedText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SoftCreamText
import com.example.ui.theme.UltraEcoRedAmber
import com.example.ui.theme.WarmAmber
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private data class ClockParts(
    val primaryLeft: String,
    val primaryRight: String,
    val secondarySeconds: String?,
    val accessibilityText: String
)

private fun splitClockParts(
    ms: Long,
    mode: StudyMode,
    showSeconds: Boolean
): ClockParts {
    val safeMs = ms.coerceAtLeast(0L)
    val totalSeconds = if (mode == StudyMode.POMODORO) {
        (safeMs + 999L) / 1000L
    } else {
        safeMs / 1000L
    }

    // Even in Minute-Only Eco mode, automatically show seconds during the final 60s of Pomodoro
    val effectiveShowSeconds = showSeconds || (mode == StudyMode.POMODORO && totalSeconds in 1L..59L)

    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L

    return if (hours > 0L) {
        val hStr = String.format(Locale.US, "%02d", hours)
        val mStr = String.format(Locale.US, "%02d", minutes)
        val sStr = if (effectiveShowSeconds) String.format(Locale.US, "%02d", seconds) else null
        val fullText = if (sStr != null) "$hStr:$mStr:$sStr" else "$hStr:$mStr"
        ClockParts(
            primaryLeft = hStr,
            primaryRight = mStr,
            secondarySeconds = sStr,
            accessibilityText = fullText
        )
    } else {
        val mStr = String.format(Locale.US, "%02d", minutes)
        val sStr = String.format(Locale.US, "%02d", seconds)
        if (effectiveShowSeconds) {
            ClockParts(
                primaryLeft = mStr,
                primaryRight = sStr,
                secondarySeconds = null,
                accessibilityText = "$mStr:$sStr"
            )
        } else {
            ClockParts(
                primaryLeft = "00",
                primaryRight = mStr,
                secondarySeconds = null,
                accessibilityText = "00:$mStr"
            )
        }
    }
}

/**
 * Battery-engineered pure AMOLED ClockDisplay:
 * - Zero continuous 60/120Hz GPU animations (allows LTPO displays to idle at 1-10Hz!).
 * - Supports OLED subpixel-saving tints (Luminous White, Warm Amber, Ultra-Eco Red-Amber).
 * - Minute-stepped discrete OLED burn-in drift (zero intermediate animation frames).
 * - Massive auto-scaled tabular JetBrains Mono typography for landscape desk viewing.
 */
@Composable
fun ClockDisplay(
    timer: TimerSnapshot,
    activeMode: StudyMode,
    showSeconds: Boolean,
    dimModeEnabled: Boolean,
    dimBrightness: Float,
    oledTint: OledTint,
    ultraBatteryMode: Boolean,
    isZenMode: Boolean,
    isLandscape: Boolean,
    strings: StudyStrings,
    onClockTap: () -> Unit,
    onVoicePillClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = MaterialTheme.colorScheme.primary
    val parts = remember(timer.displayTimeMs, activeMode, showSeconds) {
        splitClockParts(
            ms = if (activeMode == StudyMode.POMODORO) timer.remainingMs else timer.elapsedMs,
            mode = activeMode,
            showSeconds = showSeconds
        )
    }

    // Ultra-low luminance scaling when Night Dim / Eco mode is enabled (direct OLED current reduction)
    val luminance = if (dimModeEnabled) {
        (0.18f + dimBrightness * 0.62f).coerceIn(0.18f, 0.85f)
    } else {
        1.0f
    }

    // Discrete minute-stepped OLED burn-in pixel shift (zero continuous GPU frames!)
    val driftStep = (timer.elapsedMs / 60_000L).toInt()
    val burnInOffsetX = if (isZenMode || dimModeEnabled) (sin(driftStep * 0.9) * 5.0).dp else 0.dp
    val burnInOffsetY = if (isZenMode || dimModeEnabled) (cos(driftStep * 0.7) * 4.0).dp else 0.dp

    val baseDigitColor = when (oledTint) {
        OledTint.LUMINOUS_WHITE -> SoftCreamText
        OledTint.WARM_AMBER -> WarmAmber
        OledTint.ULTRA_ECO_RED -> UltraEcoRedAmber
    }
    val digitColor = baseDigitColor.copy(alpha = luminance)
    val accentColor = when (oledTint) {
        OledTint.ULTRA_ECO_RED -> UltraEcoRedAmber.copy(alpha = luminance * 0.9f)
        else -> accent.copy(alpha = if (dimModeEnabled) luminance * 0.9f else 1f)
    }
    val colonColor = accentColor.copy(alpha = (luminance * 0.78f).coerceAtLeast(0.16f))

    val statusText = when (timer.status) {
        TimerStatus.IDLE -> strings.statusReady
        TimerStatus.RUNNING -> strings.statusRunning
        TimerStatus.PAUSED -> strings.statusPaused
        TimerStatus.COMPLETED -> strings.statusCompleted
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Button,
                onClick = onClockTap
            )
            .semantics { contentDescription = "$statusText ${parts.accessibilityText}" }
            .testTag("clock_display_area"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = burnInOffsetX, y = burnInOffsetY)
                .padding(horizontal = if (isLandscape) 8.dp else 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Minimal live status indicator (hidden in Landscape non-Zen & hidden in Zen unless Completed)
            AnimatedVisibility(
                visible = (!isLandscape && !isZenMode) || timer.status == TimerStatus.COMPLETED,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(bottom = if (isLandscape) 4.dp else 14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                when (timer.status) {
                                    TimerStatus.RUNNING -> accentColor
                                    TimerStatus.PAUSED -> MutedText.copy(alpha = 0.65f)
                                    TimerStatus.COMPLETED -> accentColor
                                    TimerStatus.IDLE -> MutedText.copy(alpha = 0.4f)
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = statusText.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (timer.status == TimerStatus.RUNNING || timer.status == TimerStatus.COMPLETED) {
                            accentColor
                        } else {
                            MutedText.copy(alpha = luminance)
                        },
                        letterSpacing = 1.6.sp
                    )
                }
            }

            // MASSIVE STATIC ZERO-JITTER DESK CLOCK TYPOGRAPHY
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = isLandscape),
                contentAlignment = Alignment.Center
            ) {
                val density = LocalDensity.current
                val fontScale = density.fontScale.coerceAtLeast(1f)
                val hasSecondarySeconds = parts.secondarySeconds != null

                // Minute-only mode ("02:00", 5 chars) gets even LARGER typography while drawing 60x fewer frames!
                val effectiveChars = if (hasSecondarySeconds) 6.55f else 5.10f
                val widthAllowance = maxWidth.value * 0.96f
                val heightAllowance = maxHeight.value * when {
                    isLandscape && isZenMode -> 0.92f
                    isLandscape -> 0.88f
                    else -> 0.72f
                }

                val widthBasedSp = (widthAllowance / (effectiveChars * 0.605f)) / fontScale
                val heightBasedSp = (heightAllowance * 0.90f) / fontScale
                val targetPrimarySp = minOf(widthBasedSp, heightBasedSp).coerceIn(52f, 270f)

                var overflowMultiplier by remember(
                    parts.primaryLeft.length,
                    hasSecondarySeconds,
                    maxWidth,
                    maxHeight,
                    isZenMode
                ) {
                    mutableFloatStateOf(1f)
                }

                val primarySp = (targetPrimarySp * overflowMultiplier).coerceAtLeast(36f)
                val secondarySp = (primarySp * 0.44f).coerceAtLeast(20f)

                val annotatedClock = remember(
                    parts.primaryLeft,
                    parts.primaryRight,
                    parts.secondarySeconds,
                    digitColor,
                    colonColor,
                    accentColor,
                    primarySp,
                    secondarySp
                ) {
                    buildAnnotatedString {
                        withStyle(
                            SpanStyle(
                                color = digitColor,
                                fontSize = primarySp.sp,
                                fontWeight = FontWeight.Bold
                            )
                        ) {
                            append(parts.primaryLeft)
                        }
                        withStyle(
                            SpanStyle(
                                color = colonColor,
                                fontSize = primarySp.sp,
                                fontWeight = FontWeight.Bold
                            )
                        ) {
                            append(":")
                        }
                        withStyle(
                            SpanStyle(
                                color = digitColor,
                                fontSize = primarySp.sp,
                                fontWeight = FontWeight.Bold
                            )
                        ) {
                            append(parts.primaryRight)
                        }
                        if (parts.secondarySeconds != null) {
                            withStyle(
                                SpanStyle(
                                    color = accentColor.copy(alpha = 0.85f),
                                    fontSize = secondarySp.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            ) {
                                append(":")
                                append(parts.secondarySeconds)
                            }
                        }
                    }
                }

                Text(
                    text = annotatedClock,
                    style = TextStyle(
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = primarySp.sp,
                        lineHeight = (primarySp * 1.02f).sp,
                        letterSpacing = (-primarySp * 0.035f).sp,
                        fontFeatureSettings = "tnum"
                    ),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Visible,
                    textAlign = TextAlign.Center,
                    onTextLayout = { layoutResult ->
                        if (layoutResult.didOverflowWidth && overflowMultiplier > 0.62f) {
                            overflowMultiplier *= 0.94f
                        }
                    },
                    modifier = Modifier.testTag("clock_digits_text")
                )
            }

            Spacer(modifier = Modifier.height(if (isLandscape) 6.dp else 16.dp))

            // Ultra-thin OLED progress hairline (minimal lit pixels, zero animation overhead)
            val progress = timer.progressFraction
            Canvas(
                modifier = Modifier
                    .widthIn(max = if (isLandscape) 640.dp else 340.dp)
                    .fillMaxWidth(if (isLandscape) 0.72f else 0.84f)
                    .height(if (isZenMode || ultraBatteryMode) 2.dp else 4.dp)
            ) {
                val trackRadius = CornerRadius(size.height / 2f, size.height / 2f)
                drawRoundRect(
                    color = ObsidianBorder.copy(alpha = if (dimModeEnabled) 0.30f else 0.80f),
                    size = size,
                    cornerRadius = trackRadius
                )
                val fillWidth = (size.width * progress).coerceIn(0f, size.width)
                if (fillWidth > 0f) {
                    drawRoundRect(
                        color = accentColor,
                        size = Size(fillWidth, size.height),
                        cornerRadius = trackRadius
                    )
                    if (!isZenMode && !ultraBatteryMode) {
                        drawCircle(
                            color = digitColor,
                            radius = size.height * 0.95f,
                            center = Offset(fillWidth, size.height / 2f)
                        )
                    }
                }
            }

            // Voice status pill: omitted completely in Ultra-Battery Zen mode so >97% of OLED pixels stay pitch black!
            val showVoicePill = (!isLandscape && !isZenMode) || (isZenMode && !ultraBatteryMode)
            if (showVoicePill) {
                Spacer(modifier = Modifier.height(if (isLandscape) 8.dp else 16.dp))

                val voiceInterval = timer.voiceIntervalMinutes
                val voiceActive = timer.voiceEnabled && voiceInterval > 0
                val voiceSummary = buildString {
                    if (!voiceActive) {
                        append("${strings.voiceLabel}: ${strings.voiceOff}")
                    } else {
                        append("${strings.everyPrefix} $voiceInterval ${strings.minutesUnit}")
                        val nextMs = timer.nextAnnouncementInMs
                        if (nextMs != null && timer.status != TimerStatus.IDLE && timer.status != TimerStatus.COMPLETED) {
                            val compactNext = if (showSeconds) {
                                TimerStateHolder.formatCountdownCompact(nextMs)
                            } else {
                                val nextMin = ((nextMs + 59_999L) / 60_000L).coerceAtLeast(1L)
                                "$nextMin${strings.minutesUnit}"
                            }
                            append("  •  ${strings.nextVoicePrefix} $compactNext")
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            if (isZenMode) Color.Transparent
                            else ObsidianSurface.copy(alpha = if (dimModeEnabled) 0.55f else 0.95f)
                        )
                        .border(
                            width = if (isZenMode) 0.dp else 1.dp,
                            color = if (isZenMode) Color.Transparent
                            else if (voiceActive) accentColor.copy(alpha = 0.35f) else ObsidianBorder,
                            shape = RoundedCornerShape(999.dp)
                        )
                        .clickable(enabled = !isZenMode, onClick = onVoicePillClick)
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("voice_status_pill"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (voiceActive) {
                            if (timer.status == TimerStatus.RUNNING) Icons.Rounded.RecordVoiceOver
                            else Icons.Rounded.NotificationsActive
                        } else {
                            Icons.Rounded.VolumeOff
                        },
                        contentDescription = null,
                        tint = if (voiceActive) accentColor else MutedText.copy(alpha = luminance * 0.75f),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = voiceSummary,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (voiceActive) SoftCreamText.copy(alpha = luminance * 0.92f)
                        else MutedText.copy(alpha = luminance * 0.75f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (isZenMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.zenHint,
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedText.copy(alpha = 0.25f),
                    textAlign = TextAlign.Center
                )
            } else if (!isLandscape && timer.lastAnnouncementText != null && timer.status == TimerStatus.RUNNING) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "“${timer.lastAnnouncementText}”",
                    style = MaterialTheme.typography.bodyMedium,
                    color = accentColor.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }
}
