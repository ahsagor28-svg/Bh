package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// True AMOLED Pitch Black & Obsidian Hierarchy
val AmoledBlack = Color(0xFF000000)
val ObsidianSurface = Color(0xFF0A0B0F)
val ObsidianSurfaceContainer = Color(0xFF11131A)
val ObsidianSurfaceHigh = Color(0xFF191C26)
val ObsidianBorder = Color(0xFF282D3B)

// High-Contrast Warm Amber (Pomodoro / Focus Mode)
val WarmAmber = Color(0xFFFFB94A)
val WarmAmberDim = Color(0xFFA6762E)
val WarmAmberContainer = Color(0xFF2B1F0B)
val OnWarmAmber = Color(0xFF170F02)

// High-Contrast Crisp Mint Teal (Stopwatch Mode)
val CalmTeal = Color(0xFF6EE7C7)
val CalmTealDim = Color(0xFF3E8C77)
val CalmTealContainer = Color(0xFF0C2821)
val OnCalmTeal = Color(0xFF031A14)

// Ultra-Eco Red-Amber OLED Tint (Zero blue subpixels = lowest possible OLED current draw)
val UltraEcoRedAmber = Color(0xFFD95E2A)
val UltraEcoGreen = Color(0xFF4EC991)

// High-Contrast Luminous Off-White Digits & Clear Hierarchy
val SoftCreamText = Color(0xFFF7F6F2)
val MutedText = Color(0xFFA6A9B6)
val SubtleText = Color(0xFF646878)

// Status & Semantic Accents
val SoftCoral = Color(0xFFFF8370)
val SoftCoralContainer = Color(0xFF2E1410)
