package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Brightness4
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrientationLock
import com.example.model.StudyLap
import com.example.model.StudyMode
import com.example.model.UiLanguage
import com.example.model.UserPreferences
import com.example.model.VoiceLanguage
import com.example.service.TimerStateHolder
import com.example.ui.StudyStrings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.MutedText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceContainer
import com.example.ui.theme.ObsidianSurfaceHigh
import com.example.ui.theme.SoftCreamText
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DurationPickerSheet(
    currentDurationMinutes: Int,
    strings: StudyStrings,
    onDismiss: () -> Unit,
    onApplyDuration: (Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var hours by remember(currentDurationMinutes) { mutableIntStateOf(currentDurationMinutes / 60) }
    var minutes by remember(currentDurationMinutes) { mutableIntStateOf(currentDurationMinutes % 60) }

    val presets = listOf(25, 50, 60, 120, 180, 240, 300)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianSurface,
        contentColor = SoftCreamText
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 28.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = strings.setStudyDurationTitle,
                style = MaterialTheme.typography.titleLarge,
                color = SoftCreamText
            )
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = strings.quickPresets,
                style = MaterialTheme.typography.labelMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presets.forEach { presetMin ->
                    val selected = (hours * 60 + minutes) == presetMin
                    FilterChip(
                        selected = selected,
                        onClick = {
                            hours = presetMin / 60
                            minutes = presetMin % 60
                        },
                        label = {
                            Text(
                                text = TimerStateHolder.formatDurationLabel(presetMin, strings.isBn),
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = ObsidianSurfaceContainer,
                            labelColor = SoftCreamText,
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = ObsidianBorder,
                            selectedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("preset_duration_$presetMin")
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))
            Text(
                text = strings.customDuration,
                style = MaterialTheme.typography.labelMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NumberStepperCard(
                    label = strings.hoursFull,
                    value = hours,
                    onDecrement = { hours = (hours - 1).coerceAtLeast(0) },
                    onIncrement = { hours = (hours + 1).coerceAtMost(12) },
                    modifier = Modifier.weight(1f),
                    testTagPrefix = "hours"
                )
                NumberStepperCard(
                    label = strings.minutesFull,
                    value = minutes,
                    onDecrement = {
                        minutes = if (minutes >= 5) minutes - 5 else 55
                    },
                    onIncrement = {
                        minutes = (minutes + 5) % 60
                    },
                    modifier = Modifier.weight(1f),
                    testTagPrefix = "minutes"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            val totalMinutes = (hours * 60 + minutes).coerceAtLeast(1)
            Button(
                onClick = {
                    onApplyDuration(totalMinutes)
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("apply_duration_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${strings.applyDuration} (${TimerStateHolder.formatDurationLabel(totalMinutes, strings.isBn)})",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
private fun NumberStepperCard(
    label: String,
    value: Int,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit,
    modifier: Modifier = Modifier,
    testTagPrefix: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurfaceContainer,
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = onDecrement,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(ObsidianSurfaceHigh)
                        .testTag("${testTagPrefix}_dec")
                ) {
                    Icon(
                        Icons.Rounded.Remove,
                        contentDescription = "Decrease $label",
                        tint = SoftCreamText
                    )
                }
                Text(
                    text = String.format("%02d", value),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp
                    ),
                    color = SoftCreamText
                )
                IconButton(
                    onClick = onIncrement,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(ObsidianSurfaceHigh)
                        .testTag("${testTagPrefix}_inc")
                ) {
                    Icon(
                        Icons.Rounded.Add,
                        contentDescription = "Increase $label",
                        tint = SoftCreamText
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VoiceSettingsSheet(
    prefs: UserPreferences,
    activeMode: StudyMode,
    bengaliTtsAvailable: Boolean?,
    strings: StudyStrings,
    onDismiss: () -> Unit,
    onSetVoiceEnabled: (Boolean) -> Unit,
    onSetInterval: (Int) -> Unit,
    onSetVoiceLanguage: (VoiceLanguage) -> Unit,
    onSetChimeEnabled: (Boolean) -> Unit,
    onSetAnnounceRemaining: (Boolean) -> Unit,
    onTestVoice: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val currentInterval = if (activeMode == StudyMode.POMODORO) {
        prefs.pomodoroVoiceIntervalMinutes
    } else {
        prefs.stopwatchVoiceIntervalMinutes
    }
    var customInput by remember(currentInterval) {
        mutableStateOf(if (currentInterval > 0) currentInterval.toString() else "")
    }
    val presets = listOf(0, 5, 10, 15, 20, 25, 30, 45, 60)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianSurface,
        contentColor = SoftCreamText
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 28.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = strings.voiceSettingsTitle,
                style = MaterialTheme.typography.titleLarge,
                color = SoftCreamText
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Master Voice Toggle
            SettingSwitchRow(
                title = strings.enableVoiceAlerts,
                subtitle = null,
                checked = prefs.voiceEnabled,
                onCheckedChange = onSetVoiceEnabled,
                testTag = "switch_voice_enabled"
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = strings.intervalTitle,
                style = MaterialTheme.typography.labelMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presets.forEach { preset ->
                    val isOff = preset == 0
                    val selected = if (isOff) {
                        !prefs.voiceEnabled || currentInterval == 0
                    } else {
                        prefs.voiceEnabled && currentInterval == preset
                    }
                    FilterChip(
                        selected = selected,
                        onClick = {
                            onSetInterval(preset)
                            if (preset > 0) customInput = preset.toString()
                        },
                        label = {
                            Text(
                                text = if (isOff) strings.voiceOff else "$preset ${strings.minutesUnit}",
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = ObsidianSurfaceContainer,
                            labelColor = SoftCreamText,
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = ObsidianBorder,
                            selectedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("voice_interval_$preset")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Custom minutes input row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customInput,
                    onValueChange = { text ->
                        customInput = text.filter { it.isDigit() }.take(3)
                    },
                    label = { Text(strings.customIntervalLabel, style = MaterialTheme.typography.labelMedium) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = SoftCreamText,
                        unfocusedTextColor = SoftCreamText
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("custom_interval_input")
                )
                Button(
                    onClick = {
                        val parsed = customInput.toIntOrNull()
                        if (parsed != null && parsed in 1..180) {
                            onSetInterval(parsed)
                        }
                    },
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("apply_custom_interval_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ObsidianSurfaceHigh,
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(strings.setButton, style = MaterialTheme.typography.labelLarge)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(16.dp))

            // Voice Language Selector
            Text(
                text = strings.voiceLanguageTitle,
                style = MaterialTheme.typography.labelMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LanguageChoiceCard(
                    title = "বাংলা (Bengali)",
                    selected = prefs.voiceLanguage == VoiceLanguage.BENGALI,
                    onClick = { onSetVoiceLanguage(VoiceLanguage.BENGALI) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("voice_lang_bn")
                )
                LanguageChoiceCard(
                    title = "English",
                    selected = prefs.voiceLanguage == VoiceLanguage.ENGLISH,
                    onClick = { onSetVoiceLanguage(VoiceLanguage.ENGLISH) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("voice_lang_en")
                )
            }

            if (prefs.voiceLanguage == VoiceLanguage.BENGALI && bengaliTtsAvailable == false) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            Icons.Rounded.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.bengaliTtsMissingNote,
                            style = MaterialTheme.typography.bodyMedium,
                            color = SoftCreamText.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            SettingSwitchRow(
                title = strings.softChimeLabel,
                subtitle = null,
                checked = prefs.chimeEnabled,
                onCheckedChange = onSetChimeEnabled,
                testTag = "switch_chime"
            )

            if (activeMode == StudyMode.POMODORO) {
                Spacer(modifier = Modifier.height(8.dp))
                SettingSwitchRow(
                    title = strings.announceRemainingLabel,
                    subtitle = null,
                    checked = prefs.announceRemainingInPomodoro,
                    onCheckedChange = onSetAnnounceRemaining,
                    testTag = "switch_announce_remaining"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = onTestVoice,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("test_voice_button"),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Rounded.VolumeUp, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(strings.testVoiceButton, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisplaySettingsSheet(
    prefs: UserPreferences,
    strings: StudyStrings,
    onDismiss: () -> Unit,
    onSetUltraBatteryMode: (Boolean) -> Unit,
    onSetOledTint: (com.example.model.OledTint) -> Unit,
    onSetAutoZenAfterStart: (Boolean) -> Unit,
    onSetDimMode: (Boolean) -> Unit,
    onSetDimBrightness: (Float) -> Unit,
    onSetKeepScreenOn: (Boolean) -> Unit,
    onSetShowSeconds: (Boolean) -> Unit,
    onSetOrientationLock: (OrientationLock) -> Unit,
    onSetUiLanguage: (UiLanguage) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianSurface,
        contentColor = SoftCreamText
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 28.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = strings.displaySettingsTitle,
                style = MaterialTheme.typography.titleLarge,
                color = SoftCreamText
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Hero Card: 1-Tap Ultra Battery Saver (Eco AMOLED)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = if (prefs.ultraBatteryMode) {
                    com.example.ui.theme.UltraEcoGreen.copy(alpha = 0.12f)
                } else {
                    ObsidianSurfaceContainer
                },
                border = BorderStroke(
                    1.dp,
                    if (prefs.ultraBatteryMode) {
                        com.example.ui.theme.UltraEcoGreen.copy(alpha = 0.55f)
                    } else {
                        ObsidianBorder
                    }
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSetUltraBatteryMode(!prefs.ultraBatteryMode) }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = strings.ultraBatteryTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (prefs.ultraBatteryMode) com.example.ui.theme.UltraEcoGreen else SoftCreamText
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = strings.ultraBatteryDesc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedText
                        )
                    }
                    Switch(
                        checked = prefs.ultraBatteryMode,
                        onCheckedChange = onSetUltraBatteryMode,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = com.example.ui.theme.UltraEcoGreen,
                            uncheckedThumbColor = MutedText,
                            uncheckedTrackColor = ObsidianSurfaceHigh,
                            uncheckedBorderColor = ObsidianBorder
                        ),
                        modifier = Modifier.testTag("switch_ultra_battery")
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // OLED Subpixel Power Color Picker (White / Amber / Ultra-Eco Red)
            Text(
                text = strings.oledTintTitle,
                style = MaterialTheme.typography.labelMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val tints = listOf(
                    com.example.model.OledTint.LUMINOUS_WHITE to strings.tintWhite,
                    com.example.model.OledTint.WARM_AMBER to strings.tintAmber,
                    com.example.model.OledTint.ULTRA_ECO_RED to strings.tintUltraRed
                )
                tints.forEach { (tint, label) ->
                    LanguageChoiceCard(
                        title = label,
                        selected = prefs.oledTint == tint,
                        onClick = { onSetOledTint(tint) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("oled_tint_${tint.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AMOLED Night Dim Mode + 2%-100% Brightness Slider
            SettingSwitchRow(
                title = strings.dimLightTitle,
                subtitle = strings.dimLightDesc,
                checked = prefs.dimModeEnabled,
                onCheckedChange = onSetDimMode,
                testTag = "switch_dim_mode"
            )

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ObsidianSurfaceContainer,
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Brightness4,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.brightnessLabel,
                                style = MaterialTheme.typography.bodyLarge,
                                color = SoftCreamText
                            )
                        }
                        Text(
                            text = "${(prefs.dimBrightness * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = prefs.dimBrightness,
                        onValueChange = { value ->
                            onSetDimBrightness(value)
                            if (!prefs.dimModeEnabled) onSetDimMode(true)
                        },
                        valueRange = 0.02f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = ObsidianBorder
                        ),
                        modifier = Modifier.testTag("dim_brightness_slider")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            SettingSwitchRow(
                title = strings.autoZenTitle,
                subtitle = strings.autoZenDesc,
                checked = prefs.autoZenAfterStart,
                onCheckedChange = onSetAutoZenAfterStart,
                testTag = "switch_auto_zen"
            )

            Spacer(modifier = Modifier.height(10.dp))
            SettingSwitchRow(
                title = strings.keepScreenOnTitle,
                subtitle = strings.keepScreenOnDesc,
                checked = prefs.keepScreenOn,
                onCheckedChange = onSetKeepScreenOn,
                testTag = "switch_keep_screen_on"
            )

            Spacer(modifier = Modifier.height(10.dp))
            SettingSwitchRow(
                title = strings.showSecondsTitle,
                subtitle = strings.showSecondsDesc,
                checked = prefs.showSeconds,
                onCheckedChange = onSetShowSeconds,
                testTag = "switch_show_seconds"
            )

            Spacer(modifier = Modifier.height(18.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(16.dp))

            // Orientation Control
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.ScreenRotation,
                    contentDescription = null,
                    tint = MutedText,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = strings.orientationTitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedText
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val options = listOf(
                    OrientationLock.AUTO to strings.orientAuto,
                    OrientationLock.LANDSCAPE to strings.orientLandscape,
                    OrientationLock.PORTRAIT to strings.orientPortrait
                )
                options.forEach { (lock, label) ->
                    LanguageChoiceCard(
                        title = label,
                        selected = prefs.orientationLock == lock,
                        onClick = { onSetOrientationLock(lock) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("orient_${lock.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // App UI Language
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.Language,
                    contentDescription = null,
                    tint = MutedText,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = strings.uiLanguageTitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedText
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LanguageChoiceCard(
                    title = "বাংলা",
                    selected = prefs.uiLanguage == UiLanguage.BENGALI,
                    onClick = { onSetUiLanguage(UiLanguage.BENGALI) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ui_lang_bn")
                )
                LanguageChoiceCard(
                    title = "English",
                    selected = prefs.uiLanguage == UiLanguage.ENGLISH,
                    onClick = { onSetUiLanguage(UiLanguage.ENGLISH) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ui_lang_en")
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Deep-Sleep Background Engine Info Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ObsidianSurfaceContainer,
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        Icons.Rounded.Shield,
                        contentDescription = null,
                        tint = com.example.ui.theme.UltraEcoGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = strings.backgroundTipTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = SoftCreamText
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = strings.backgroundTipDesc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedText
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LapsBottomSheet(
    laps: List<StudyLap>,
    strings: StudyStrings,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianSurface,
        contentColor = SoftCreamText
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 28.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = strings.lapHistoryTitle,
                style = MaterialTheme.typography.titleLarge,
                color = SoftCreamText
            )
            Spacer(modifier = Modifier.height(14.dp))

            if (laps.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = MutedText.copy(alpha = 0.5f),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = strings.noLapsYet,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedText
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(laps, key = { it.index }) { lap ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = ObsidianSurfaceContainer,
                            border = BorderStroke(1.dp, ObsidianBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "#${lap.index}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontFamily = JetBrainsMonoFamily
                                    ),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${strings.splitLabel}: +${TimerStateHolder.formatStopwatchClock(lap.splitMs)}",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontFamily = JetBrainsMonoFamily
                                        ),
                                        color = MutedText
                                    )
                                    Text(
                                        text = "${strings.totalLabel}: ${TimerStateHolder.formatStopwatchClock(lap.totalElapsedMs)}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontFamily = JetBrainsMonoFamily
                                        ),
                                        color = SoftCreamText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = SoftCreamText
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = MutedText,
                uncheckedTrackColor = ObsidianSurfaceHigh,
                uncheckedBorderColor = ObsidianBorder
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun LanguageChoiceCard(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = MaterialTheme.colorScheme.primary
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else ObsidianSurfaceContainer)
            .border(
                width = 1.dp,
                color = if (selected) accent.copy(alpha = 0.7f) else ObsidianBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) accent else SoftCreamText,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
