package com.example.ui

import com.example.model.UiLanguage

class StudyStrings(private val lang: UiLanguage) {
    val isBn: Boolean get() = lang == UiLanguage.BENGALI

    val pomodoro: String get() = if (isBn) "পোমোডোরো" else "Pomodoro"
    val stopwatch: String get() = if (isBn) "স্টপওয়াচ" else "Stopwatch"

    val start: String get() = if (isBn) "শুরু করুন" else "Start"
    val pause: String get() = if (isBn) "বিরতি" else "Pause"
    val resume: String get() = if (isBn) "চালু করুন" else "Resume"
    val restart: String get() = if (isBn) "আবার শুরু" else "Restart"
    val reset: String get() = if (isBn) "রিসেট" else "Reset"
    val lap: String get() = if (isBn) "ল্যাপ" else "Lap"
    val laps: String get() = if (isBn) "মাইলস্টোন" else "Laps"
    val add15Min: String get() = if (isBn) "+১৫ মি." else "+15m"
    val done: String get() = if (isBn) "সম্পন্ন" else "Done"

    val statusReady: String get() = if (isBn) "পড়াশোনার জন্য প্রস্তুত" else "Ready to focus"
    val statusRunning: String get() = if (isBn) "পড়াশোনা চলছে" else "Deep focus active"
    val statusPaused: String get() = if (isBn) "বিরতিতে আছে" else "Paused"
    val statusCompleted: String get() = if (isBn) "সময় সম্পন্ন! দারুণ কাজ!" else "Session complete!"

    val durationLabel: String get() = if (isBn) "সময় সেট" else "Duration"
    val voiceLabel: String get() = if (isBn) "ভয়েস অ্যালার্ট" else "Voice Alert"
    val voiceOff: String get() = if (isBn) "বন্ধ" else "Off"
    val nextVoicePrefix: String get() = if (isBn) "পরবর্তী ভয়েস" else "Next voice"
    val everyPrefix: String get() = if (isBn) "প্রতি" else "Every"
    val minutesUnit: String get() = if (isBn) "মি." else "m"
    val minutesFull: String get() = if (isBn) "মিনিট" else "min"
    val hoursFull: String get() = if (isBn) "ঘণ্টা" else "hr"

    val todayStudyLabel: String get() = if (isBn) "আজকের পড়া" else "Today"
    val ecoBadge: String get() = if (isBn) "ইকো" else "ECO"
    val zenHint: String get() = if (isBn) "ইকো AMOLED মোড • ফিরতে ট্যাপ করুন" else "Eco AMOLED • Tap to show controls"
    val tapClockForZen: String get() = if (isBn) "ঘড়িতে ট্যাপ করলে ফুলস্ক্রিন হবে" else "Tap clock for fullscreen desk mode"

    // Duration Picker Sheet
    val setStudyDurationTitle: String get() = if (isBn) "পড়াশোনার সময় ঠিক করুন" else "Set Study Duration"
    val quickPresets: String get() = if (isBn) "দ্রুত প্রিসেট" else "Quick Presets"
    val customDuration: String get() = if (isBn) "কাস্টম সময়" else "Custom Time"
    val applyDuration: String get() = if (isBn) "সময় সেট করুন" else "Apply Duration"

    // Voice Settings Sheet
    val voiceSettingsTitle: String get() = if (isBn) "ভয়েস অ্যালার্ট সেটিংস" else "Voice Alert Settings"
    val enableVoiceAlerts: String get() = if (isBn) "ভয়েস ঘোষণা চালু রাখুন" else "Enable voice announcements"
    val intervalTitle: String get() = if (isBn) "কতক্ষণ পর পর বলবে?" else "Announcement Interval"
    val customIntervalLabel: String get() = if (isBn) "কাস্টম মিনিট (১-১৮০)" else "Custom minutes (1-180)"
    val setButton: String get() = if (isBn) "সেট" else "Set"
    val voiceLanguageTitle: String get() = if (isBn) "ভয়েসের ভাষা" else "Voice Language"
    val softChimeLabel: String get() = if (isBn) "ভয়েসের আগে হালকা রিংটোন" else "Gentle chime before voice"
    val announceRemainingLabel: String get() = if (isBn) "বাকি সময়ও বলে দেবে (পোমোডোরো)" else "Also speak remaining time"
    val testVoiceButton: String get() = if (isBn) "ভয়েস টেস্ট করুন" else "Test Voice Now"
    val bengaliTtsMissingNote: String
        get() = if (isBn) {
            "ফোনে বাংলা ভয়েস প্যাক পাওয়া যায়নি—স্বয়ংক্রিয়ভাবে ইংরেজিতে বলবে। ফোনের Settings > Text-to-speech থেকে বাংলা ডাউনলোড করতে পারেন।"
        } else {
            "Bengali TTS pack not detected on this device—falling back to English. You can install Bengali in Android Text-to-Speech settings."
        }

    // Display & Battery Settings Sheet
    val displaySettingsTitle: String get() = if (isBn) "ব্যাটারি ও ডিসপ্লে সেটিংস" else "Battery & Display Settings"
    val ultraBatteryTitle: String get() = if (isBn) "আল্ট্রা ব্যাটারি সেভার (Eco AMOLED)" else "Ultra Battery Saver (Eco AMOLED)"
    val ultraBatteryDesc: String
        get() = if (isBn) {
            "প্রতি মিনিটে মাত্র ১ বার স্ক্রিন আপডেট, জিরো অ্যানিমেশন, অটো-জেন এবং সর্বনিম্ন OLED পাওয়ার।"
        } else {
            "1 redraw/min, zero GPU animations, auto-Zen black screen, and lowest-power OLED subpixels."
        }
    val oledTintTitle: String get() = if (isBn) "OLED ঘড়ির রঙ (ব্যাটারি সাশ্রয়)" else "OLED Digit Color (Power Tier)"
    val tintWhite: String get() = if (isBn) "হোয়াইট" else "White"
    val tintAmber: String get() = if (isBn) "অ্যাম্বার" else "Amber"
    val tintUltraRed: String get() = if (isBn) "ইকো রেড" else "Eco Red"
    val dimLightTitle: String get() = if (isBn) "AMOLED ডিম লাইট মোড" else "AMOLED Night Dim Mode"
    val dimLightDesc: String get() = if (isBn) "হালকা আলোতে চোখ ও ব্যাটারি দুটোই নিরাপদ থাকে" else "Ultra-low screen brightness down to 2%"
    val brightnessLabel: String get() = if (isBn) "ডিম আলোর মাত্রা" else "Dim Light Level"
    val autoZenTitle: String get() = if (isBn) "১৫ সেকেন্ড পর অটো-জেন মোড" else "Auto-Zen after 15 seconds"
    val autoZenDesc: String get() = if (isBn) "সব বাটন লুকিয়ে ৯৭% পিক্সেল পুরো বন্ধ রাখবে" else "Hides all chrome so 97%+ of OLED pixels turn off"
    val keepScreenOnTitle: String get() = if (isBn) "পড়ার সময় স্ক্রিন চালু রাখুন" else "Keep Screen On While Running"
    val keepScreenOnDesc: String
        get() = if (isBn) {
            "সর্বোচ্চ ব্যাটারি বাঁচাতে এটি বন্ধ রাখুন—স্ক্রিন অফ হলেও ভয়েস অ্যালার্ট ঠিক সময়েই চলবে!"
        } else {
            "Turn OFF for maximum battery—CPU deep-sleeps between voice alerts while screen is off!"
        }
    val showSecondsTitle: String get() = if (isBn) "সেকেন্ড দেখান (বেশি ব্যাটারি খরচ)" else "Show Seconds (uses more battery)"
    val showSecondsDesc: String
        get() = if (isBn) {
            "বন্ধ রাখলে প্রতি মিনিটে ১ বার আপডেট হয়ে ৬০ গুণ কম গ্রাফিক্স পাওয়ার লাগে"
        } else {
            "Off = 1 redraw per minute (60x fewer display updates; last 60s still shown)"
        }
    val orientationTitle: String get() = if (isBn) "স্ক্রিন রোটেশন" else "Screen Orientation"
    val orientAuto: String get() = if (isBn) "অটো" else "Auto"
    val orientLandscape: String get() = if (isBn) "ল্যান্ডস্কেপ" else "Landscape"
    val orientPortrait: String get() = if (isBn) "পোর্ট্রেট" else "Portrait"
    val uiLanguageTitle: String get() = if (isBn) "অ্যাপের ভাষা" else "App Language"
    val backgroundTipTitle: String get() = if (isBn) "ডিপ-স্লিপ ব্যাকগ্রাউন্ড ইঞ্জিন" else "Deep-Sleep Background Engine"
    val backgroundTipDesc: String
        get() = if (isBn) {
            "স্ক্রিন বন্ধ থাকলে CPU সম্পূর্ণ ঘুমিয়ে থাকে এবং শুধু ভয়েস বলার মুহূর্তেই জেগে ওঠে—ঘণ্টায় ১%-এরও কম চার্জ খরচ হয়।"
        } else {
            "When screen is off, the service sleeps directly until the exact voice alert—waking ~3 times/hour instead of continuously."
        }
    val noLapsYet: String get() = if (isBn) "এখনো কোনো ল্যাপ রেকর্ড করা হয়নি" else "No milestones recorded yet"
    val lapHistoryTitle: String get() = if (isBn) "স্টাডি মাইলস্টোন (ল্যাপ)" else "Study Milestones (Laps)"
    val splitLabel: String get() = if (isBn) "পার্থক্য" else "Split"
    val totalLabel: String get() = if (isBn) "মোট" else "Total"
}
