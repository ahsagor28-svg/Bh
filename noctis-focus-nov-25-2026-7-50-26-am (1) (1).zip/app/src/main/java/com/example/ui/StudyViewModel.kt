package com.example.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PreferencesRepository
import com.example.model.OledTint
import com.example.model.OrientationLock
import com.example.model.StudyMode
import com.example.model.TimerSnapshot
import com.example.model.TimerStatus
import com.example.model.UiLanguage
import com.example.model.UserPreferences
import com.example.model.VoiceLanguage
import com.example.service.StudyTimerService
import com.example.service.TimerStateHolder
import com.example.voice.VoiceAnnouncer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class StudyUiState(
    val prefs: UserPreferences = UserPreferences(),
    val timer: TimerSnapshot = TimerSnapshot(),
    val bengaliTtsAvailable: Boolean? = null,
    val isZenMode: Boolean = false
) {
    val activeMode: StudyMode
        get() = if (timer.status == TimerStatus.IDLE) prefs.mode else timer.mode

    val isTimerActive: Boolean
        get() = timer.status == TimerStatus.RUNNING || timer.status == TimerStatus.PAUSED
}

class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val prefsRepository = PreferencesRepository(appContext)
    private val isZenModeFlow = MutableStateFlow(false)

    // Lightweight local VoiceAnnouncer for instant TTS probing and idle voice testing
    private val previewVoiceAnnouncer = VoiceAnnouncer(appContext)

    val uiState: StateFlow<StudyUiState> = combine(
        prefsRepository.preferencesFlow,
        TimerStateHolder.snapshot,
        TimerStateHolder.bengaliTtsAvailable,
        isZenModeFlow
    ) { prefs, snapshot, bnAvail, zen ->
        StudyUiState(
            prefs = prefs,
            timer = snapshot,
            bengaliTtsAvailable = bnAvail,
            isZenMode = zen
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = StudyUiState()
    )

    init {
        viewModelScope.launch {
            prefsRepository.preferencesFlow.collect { prefs ->
                TimerStateHolder.syncIdleConfig(
                    mode = prefs.mode,
                    pomodoroDurationMinutes = prefs.pomodoroDurationMinutes,
                    voiceIntervalMinutes = prefs.activeVoiceIntervalMinutes,
                    voiceEnabled = prefs.voiceEnabled
                )
            }
        }
    }

    fun selectMode(mode: StudyMode) {
        val currentStatus = uiState.value.timer.status
        viewModelScope.launch {
            if (currentStatus != TimerStatus.IDLE) {
                resetTimer()
            }
            prefsRepository.setMode(mode)
        }
    }

    fun startOrResumeTimer() {
        val state = uiState.value
        val intent = Intent(appContext, StudyTimerService::class.java).apply {
            action = StudyTimerService.ACTION_START_OR_RESUME
            putExtra(StudyTimerService.EXTRA_MODE, state.prefs.mode.name)
            putExtra(StudyTimerService.EXTRA_TARGET_MINUTES, state.prefs.pomodoroDurationMinutes)
        }
        ContextCompat.startForegroundService(appContext, intent)
    }

    fun pauseTimer() {
        val intent = Intent(appContext, StudyTimerService::class.java).apply {
            action = StudyTimerService.ACTION_PAUSE
        }
        appContext.startService(intent)
    }

    fun resetTimer() {
        isZenModeFlow.value = false
        val intent = Intent(appContext, StudyTimerService::class.java).apply {
            action = StudyTimerService.ACTION_RESET
        }
        appContext.startService(intent)
    }

    fun add15Minutes() {
        val state = uiState.value
        if (state.timer.status == TimerStatus.IDLE) {
            setPomodoroDuration((state.prefs.pomodoroDurationMinutes + 15).coerceAtMost(720))
        } else {
            val intent = Intent(appContext, StudyTimerService::class.java).apply {
                action = StudyTimerService.ACTION_ADD_15_MIN
            }
            appContext.startService(intent)
        }
    }

    fun recordLap() {
        if (uiState.value.timer.status == TimerStatus.IDLE) return
        val intent = Intent(appContext, StudyTimerService::class.java).apply {
            action = StudyTimerService.ACTION_RECORD_LAP
        }
        appContext.startService(intent)
    }

    fun setPomodoroDuration(minutes: Int) {
        viewModelScope.launch {
            prefsRepository.setPomodoroDuration(minutes)
        }
    }

    fun setVoiceInterval(minutes: Int) {
        val mode = uiState.value.activeMode
        viewModelScope.launch {
            prefsRepository.setVoiceInterval(mode, minutes)
            if (minutes == 0) {
                prefsRepository.setVoiceEnabled(false)
            }
        }
    }

    fun setVoiceEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setVoiceEnabled(enabled)
        }
    }

    fun setChimeEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setChimeEnabled(enabled)
        }
    }

    fun setAnnounceRemaining(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setAnnounceRemaining(enabled)
        }
    }

    fun setVoiceLanguage(language: VoiceLanguage) {
        viewModelScope.launch {
            prefsRepository.setVoiceLanguage(language)
        }
    }

    fun setUiLanguage(language: UiLanguage) {
        viewModelScope.launch {
            prefsRepository.setUiLanguage(language)
        }
    }

    fun toggleUltraBatteryMode() {
        setUltraBatteryMode(!uiState.value.prefs.ultraBatteryMode)
    }

    fun setUltraBatteryMode(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setUltraBatteryMode(enabled)
        }
    }

    fun setOledTint(tint: OledTint) {
        viewModelScope.launch {
            prefsRepository.setOledTint(tint)
        }
    }

    fun setAutoZenAfterStart(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setAutoZenAfterStart(enabled)
        }
    }

    fun setKeepScreenOn(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setKeepScreenOn(enabled)
        }
    }

    fun toggleDimMode() {
        val current = uiState.value.prefs.dimModeEnabled
        viewModelScope.launch {
            prefsRepository.setDimModeEnabled(!current)
        }
    }

    fun setDimModeEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setDimModeEnabled(enabled)
        }
    }

    fun setDimBrightness(brightness: Float) {
        viewModelScope.launch {
            prefsRepository.setDimBrightness(brightness)
        }
    }

    fun setShowSeconds(show: Boolean) {
        viewModelScope.launch {
            prefsRepository.setShowSeconds(show)
        }
    }

    fun setOrientationLock(lock: OrientationLock) {
        viewModelScope.launch {
            prefsRepository.setOrientationLock(lock)
        }
    }

    fun toggleLandscapeQuick(currentlyLandscape: Boolean) {
        val target = if (currentlyLandscape) {
            OrientationLock.PORTRAIT
        } else {
            OrientationLock.LANDSCAPE
        }
        setOrientationLock(target)
    }

    fun toggleZenMode() {
        isZenModeFlow.value = !isZenModeFlow.value
    }

    fun enterZenMode() {
        isZenModeFlow.value = true
    }

    fun exitZenMode() {
        isZenModeFlow.value = false
    }

    fun testVoiceNow() {
        val state = uiState.value
        if (state.isTimerActive) {
            val intent = Intent(appContext, StudyTimerService::class.java).apply {
                action = StudyTimerService.ACTION_TEST_VOICE
            }
            appContext.startService(intent)
        } else {
            val spoken = previewVoiceAnnouncer.speakTest(
                language = state.prefs.voiceLanguage,
                intervalMinutes = state.prefs.activeVoiceIntervalMinutes.coerceAtLeast(1),
                playChime = state.prefs.chimeEnabled
            )
            TimerStateHolder.updateSnapshot { it.copy(lastAnnouncementText = spoken) }
        }
    }

    override fun onCleared() {
        previewVoiceAnnouncer.release()
        super.onCleared()
    }
}
