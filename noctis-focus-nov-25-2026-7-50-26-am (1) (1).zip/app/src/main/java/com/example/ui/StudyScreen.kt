package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.OledTint
import com.example.model.OrientationLock
import com.example.model.StudyMode
import com.example.model.TimerSnapshot
import com.example.model.TimerStatus
import com.example.model.UiLanguage
import com.example.model.UserPreferences
import com.example.model.VoiceLanguage
import com.example.service.TimerStateHolder
import com.example.ui.components.ClockDisplay
import com.example.ui.components.DisplaySettingsSheet
import com.example.ui.components.DurationPickerSheet
import com.example.ui.components.LapsBottomSheet
import com.example.ui.components.VoiceSettingsSheet
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.MutedText
import com.example.ui.theme.NoctisFocusTheme
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceContainer
import com.example.ui.theme.ObsidianSurfaceHigh
import com.example.ui.theme.SoftCreamText
import com.example.ui.theme.UltraEcoGreen
import kotlinx.coroutines.delay

@Composable
fun StudyScreen(
    uiState: StudyUiState,
    onRequestStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onReset: () -> Unit,
    onSelectMode: (StudyMode) -> Unit,
    onAdd15Min: () -> Unit,
    onRecordLap: () -> Unit,
    onSetPomodoroDuration: (Int) -> Unit,
    onSetVoiceInterval: (Int) -> Unit,
    onSetVoiceEnabled: (Boolean) -> Unit,
    onSetVoiceLanguage: (VoiceLanguage) -> Unit,
    onSetChimeEnabled: (Boolean) -> Unit,
    onSetAnnounceRemaining: (Boolean) -> Unit,
    onTestVoice: () -> Unit,
    onToggleUltraBatteryMode: () -> Unit,
    onSetUltraBatteryMode: (Boolean) -> Unit,
    onSetOledTint: (OledTint) -> Unit,
    onSetAutoZenAfterStart: (Boolean) -> Unit,
    onSetDimMode: (Boolean) -> Unit,
    onSetDimBrightness: (Float) -> Unit,
    onSetKeepScreenOn: (Boolean) -> Unit,
    onSetShowSeconds: (Boolean) -> Unit,
    onSetOrientationLock: (OrientationLock) -> Unit,
    onToggleLandscapeQuick: (Boolean) -> Unit,
    onSetUiLanguage: (UiLanguage) -> Unit,
    onToggleZenMode: () -> Unit,
    onEnterZenMode: () -> Unit,
    onExitZenMode: () -> Unit
) {
    val strings = remember(uiState.prefs.uiLanguage) { StudyStrings(uiState.prefs.uiLanguage) }
    var showDurationSheet by remember { mutableStateOf(false) }
    var showVoiceSheet by remember { mutableStateOf(false) }
    var showDisplaySheet by remember { mutableStateOf(false) }
    var showLapsSheet by remember { mutableStateOf(false) }

    val anySheetOpen = showDurationSheet || showVoiceSheet || showDisplaySheet || showLapsSheet

    // Auto-Zen battery saver: 15s after running with no dialog open, hide all UI chrome
    // so 97%+ of AMOLED pixels stay completely OFF!
    LaunchedEffect(
        uiState.timer.status,
        uiState.prefs.autoZenAfterStart,
        uiState.isZenMode,
        anySheetOpen
    ) {
        if (uiState.timer.status == TimerStatus.RUNNING &&
            uiState.prefs.autoZenAfterStart &&
            !uiState.isZenMode &&
            !anySheetOpen
        ) {
            delay(15_000L)
            onEnterZenMode()
        }
    }

    // Back press exits fullscreen Zen mode gracefully
    BackHandler(enabled = uiState.isZenMode) {
        onExitZenMode()
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack)
    ) {
        val isLandscape = maxWidth > maxHeight
        val dimAlpha = if (uiState.prefs.dimModeEnabled) {
            (0.40f + uiState.prefs.dimBrightness * 0.50f).coerceIn(0.40f, 0.90f)
        } else {
            1f
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (uiState.isZenMode || isLandscape) Modifier.windowInsetsPadding(WindowInsets.safeDrawing)
                    else Modifier
                        .statusBarsPadding()
                        .navigationBarsPadding()
                )
                .padding(
                    horizontal = 18.dp,
                    vertical = if (isLandscape) 4.dp else 12.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP BAR: Mode Switcher + Landscape Live Telemetry + Eco Battery & Quick Tools
            AnimatedVisibility(
                visible = !uiState.isZenMode,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200))
            ) {
                TopStudyHeader(
                    uiState = uiState,
                    isLandscape = isLandscape,
                    dimAlpha = dimAlpha,
                    strings = strings,
                    onSelectMode = onSelectMode,
                    onVoicePillClick = { showVoiceSheet = true },
                    onToggleEco = onToggleUltraBatteryMode,
                    onToggleRotate = { onToggleLandscapeQuick(isLandscape) },
                    onToggleZen = onToggleZenMode,
                    onOpenSettings = { showDisplaySheet = true }
                )
            }

            // CENTERPIECE: ZERO-ANIMATION MASSIVE AMOLED CLOCK
            ClockDisplay(
                timer = uiState.timer,
                activeMode = uiState.activeMode,
                showSeconds = uiState.prefs.showSeconds,
                dimModeEnabled = uiState.prefs.dimModeEnabled,
                dimBrightness = uiState.prefs.dimBrightness,
                oledTint = uiState.prefs.oledTint,
                ultraBatteryMode = uiState.prefs.ultraBatteryMode,
                isZenMode = uiState.isZenMode,
                isLandscape = isLandscape,
                strings = strings,
                onClockTap = onToggleZenMode,
                onVoicePillClick = { showVoiceSheet = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            // BOTTOM DOCK: Quick Config Pills + Tactile Controls
            AnimatedVisibility(
                visible = !uiState.isZenMode,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200))
            ) {
                if (isLandscape) {
                    LandscapeBottomControlStrip(
                        uiState = uiState,
                        strings = strings,
                        dimAlpha = dimAlpha,
                        onOpenDuration = { showDurationSheet = true },
                        onOpenVoice = { showVoiceSheet = true },
                        onOpenLaps = { showLapsSheet = true },
                        onStartOrResume = onRequestStartOrResume,
                        onPause = onPause,
                        onReset = onReset,
                        onAdd15Min = onAdd15Min,
                        onRecordLap = onRecordLap
                    )
                } else {
                    PortraitBottomControls(
                        uiState = uiState,
                        strings = strings,
                        dimAlpha = dimAlpha,
                        onOpenDuration = { showDurationSheet = true },
                        onOpenVoice = { showVoiceSheet = true },
                        onOpenLaps = { showLapsSheet = true },
                        onStartOrResume = onRequestStartOrResume,
                        onPause = onPause,
                        onReset = onReset,
                        onAdd15Min = onAdd15Min,
                        onRecordLap = onRecordLap
                    )
                }
            }
        }
    }

    // MODALS & BOTTOM SHEETS
    if (showDurationSheet) {
        DurationPickerSheet(
            currentDurationMinutes = uiState.prefs.pomodoroDurationMinutes,
            strings = strings,
            onDismiss = { showDurationSheet = false },
            onApplyDuration = { minutes ->
                onSetPomodoroDuration(minutes)
                if (uiState.timer.status != TimerStatus.IDLE) {
                    onReset()
                }
            }
        )
    }

    if (showVoiceSheet) {
        VoiceSettingsSheet(
            prefs = uiState.prefs,
            activeMode = uiState.activeMode,
            bengaliTtsAvailable = uiState.bengaliTtsAvailable,
            strings = strings,
            onDismiss = { showVoiceSheet = false },
            onSetVoiceEnabled = onSetVoiceEnabled,
            onSetInterval = onSetVoiceInterval,
            onSetVoiceLanguage = onSetVoiceLanguage,
            onSetChimeEnabled = onSetChimeEnabled,
            onSetAnnounceRemaining = onSetAnnounceRemaining,
            onTestVoice = onTestVoice
        )
    }

    if (showDisplaySheet) {
        DisplaySettingsSheet(
            prefs = uiState.prefs,
            strings = strings,
            onDismiss = { showDisplaySheet = false },
            onSetUltraBatteryMode = onSetUltraBatteryMode,
            onSetOledTint = onSetOledTint,
            onSetAutoZenAfterStart = onSetAutoZenAfterStart,
            onSetDimMode = onSetDimMode,
            onSetDimBrightness = onSetDimBrightness,
            onSetKeepScreenOn = onSetKeepScreenOn,
            onSetShowSeconds = onSetShowSeconds,
            onSetOrientationLock = onSetOrientationLock,
            onSetUiLanguage = onSetUiLanguage
        )
    }

    if (showLapsSheet) {
        LapsBottomSheet(
            laps = uiState.timer.laps,
            strings = strings,
            onDismiss = { showLapsSheet = false }
        )
    }
}

@Composable
private fun TopStudyHeader(
    uiState: StudyUiState,
    isLandscape: Boolean,
    dimAlpha: Float,
    strings: StudyStrings,
    onSelectMode: (StudyMode) -> Unit,
    onVoicePillClick: () -> Unit,
    onToggleEco: () -> Unit,
    onToggleRotate: () -> Unit,
    onToggleZen: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val activeMode = uiState.activeMode
    val ultraEco = uiState.prefs.ultraBatteryMode
    val accent = MaterialTheme.colorScheme.primary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 1040.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Segmented Mode Toggle (Pomodoro / Stopwatch)
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(AmoledBlack)
                .border(1.dp, ObsidianBorder, RoundedCornerShape(999.dp))
                .padding(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ModeSegmentPill(
                label = strings.pomodoro,
                icon = Icons.Rounded.HourglassBottom,
                selected = activeMode == StudyMode.POMODORO,
                dimAlpha = dimAlpha,
                onClick = { onSelectMode(StudyMode.POMODORO) },
                testTag = "mode_pomodoro_button"
            )
            ModeSegmentPill(
                label = strings.stopwatch,
                icon = Icons.Rounded.Timer,
                selected = activeMode == StudyMode.STOPWATCH,
                dimAlpha = dimAlpha,
                onClick = { onSelectMode(StudyMode.STOPWATCH) },
                testTag = "mode_stopwatch_button"
            )
        }

        // Landscape integrated top telemetry bar so center canvas maximizes clock height
        if (isLandscape) {
            val timer = uiState.timer
            val voiceInterval = timer.voiceIntervalMinutes
            val voiceActive = timer.voiceEnabled && voiceInterval > 0
            val statusLabel = when (timer.status) {
                TimerStatus.IDLE -> strings.statusReady
                TimerStatus.RUNNING -> strings.statusRunning
                TimerStatus.PAUSED -> strings.statusPaused
                TimerStatus.COMPLETED -> strings.statusCompleted
            }
            val voiceChipText = buildString {
                if (!voiceActive) {
                    append(strings.voiceOff)
                } else {
                    append("${strings.everyPrefix} $voiceInterval${strings.minutesUnit}")
                    val nextMs = timer.nextAnnouncementInMs
                    if (nextMs != null && timer.status != TimerStatus.IDLE && timer.status != TimerStatus.COMPLETED) {
                        val compactNext = if (uiState.prefs.showSeconds) {
                            TimerStateHolder.formatCountdownCompact(nextMs)
                        } else {
                            val nextMin = ((nextMs + 59_999L) / 60_000L).coerceAtLeast(1L)
                            "$nextMin${strings.minutesUnit}"
                        }
                        append(" • $compactNext")
                    }
                }
            }

            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(
                            if (timer.status == TimerStatus.RUNNING || timer.status == TimerStatus.COMPLETED) {
                                accent.copy(alpha = dimAlpha)
                            } else {
                                MutedText.copy(alpha = 0.55f)
                            }
                        )
                )
                Spacer(modifier = Modifier.width(7.dp))
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = SoftCreamText.copy(alpha = dimAlpha * 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.width(10.dp))
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(ObsidianSurface)
                        .border(
                            1.dp,
                            if (voiceActive) accent.copy(alpha = 0.35f) else ObsidianBorder,
                            RoundedCornerShape(999.dp)
                        )
                        .clickable(onClick = onVoicePillClick)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("landscape_top_voice_pill"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (voiceActive) {
                            if (timer.status == TimerStatus.RUNNING) Icons.Rounded.RecordVoiceOver
                            else Icons.Rounded.NotificationsActive
                        } else {
                            Icons.Rounded.VolumeOff
                        },
                        contentDescription = null,
                        tint = if (voiceActive) accent.copy(alpha = dimAlpha) else MutedText,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = voiceChipText,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = SoftCreamText.copy(alpha = dimAlpha * 0.9f),
                        maxLines = 1
                    )
                }
            }
        }

        // Quick Utility Action Icons (Ultra Battery Eco, Rotate Landscape, Zen, Settings)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(
                onClick = onToggleEco,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("eco_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.BatterySaver,
                    contentDescription = stringResource(R.string.cd_eco_toggle),
                    tint = if (ultraEco) UltraEcoGreen.copy(alpha = dimAlpha) else MutedText.copy(alpha = dimAlpha)
                )
            }
            IconButton(
                onClick = onToggleRotate,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("rotate_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.ScreenRotation,
                    contentDescription = stringResource(R.string.cd_rotate_toggle),
                    tint = if (isLandscape) accent.copy(alpha = dimAlpha) else MutedText.copy(alpha = dimAlpha)
                )
            }
            if (isLandscape) {
                IconButton(
                    onClick = onToggleZen,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("zen_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Fullscreen,
                        contentDescription = stringResource(R.string.cd_zen_toggle),
                        tint = MutedText.copy(alpha = dimAlpha)
                    )
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = stringResource(R.string.cd_settings),
                    tint = SoftCreamText.copy(alpha = dimAlpha)
                )
            }
        }
    }
}

@Composable
private fun ModeSegmentPill(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    dimAlpha: Float,
    onClick: () -> Unit,
    testTag: String
) {
    val accent = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else AmoledBlack)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) accent.copy(alpha = dimAlpha) else MutedText.copy(alpha = dimAlpha * 0.8f),
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) accent.copy(alpha = dimAlpha) else MutedText.copy(alpha = dimAlpha * 0.85f),
            maxLines = 1
        )
    }
}

@Composable
private fun PortraitBottomControls(
    uiState: StudyUiState,
    strings: StudyStrings,
    dimAlpha: Float,
    onOpenDuration: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenLaps: () -> Unit,
    onStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onReset: () -> Unit,
    onAdd15Min: () -> Unit,
    onRecordLap: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Quick 1-tap configuration chips row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (uiState.activeMode == StudyMode.POMODORO) {
                QuickConfigCard(
                    icon = Icons.Rounded.Schedule,
                    label = strings.durationLabel,
                    value = TimerStateHolder.formatDurationLabel(uiState.prefs.pomodoroDurationMinutes, strings.isBn),
                    dimAlpha = dimAlpha,
                    onClick = onOpenDuration,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("duration_picker_card")
                )
            } else {
                QuickConfigCard(
                    icon = Icons.Rounded.Flag,
                    label = strings.laps,
                    value = if (uiState.timer.laps.isEmpty()) "0" else "${uiState.timer.laps.size}",
                    dimAlpha = dimAlpha,
                    onClick = onOpenLaps,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("laps_history_card")
                )
            }

            val intervalMin = uiState.prefs.activeVoiceIntervalMinutes
            val voiceOn = uiState.prefs.voiceEnabled && intervalMin > 0
            QuickConfigCard(
                icon = if (voiceOn) Icons.Rounded.RecordVoiceOver else Icons.Rounded.VolumeOff,
                label = strings.voiceLabel,
                value = if (voiceOn) "$intervalMin ${strings.minutesUnit}" else strings.voiceOff,
                dimAlpha = dimAlpha,
                onClick = onOpenVoice,
                modifier = Modifier
                    .weight(1f)
                    .testTag("voice_interval_card")
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        PrimaryActionControlsRow(
            uiState = uiState,
            strings = strings,
            dimAlpha = dimAlpha,
            compact = false,
            onStartOrResume = onStartOrResume,
            onPause = onPause,
            onReset = onReset,
            onAdd15Min = onAdd15Min,
            onRecordLap = onRecordLap
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (uiState.prefs.ultraBatteryMode) {
                    Text(
                        text = strings.ecoBadge,
                        style = MaterialTheme.typography.labelSmall,
                        color = UltraEcoGreen.copy(alpha = dimAlpha),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, UltraEcoGreen.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = "${strings.todayStudyLabel}: ${TimerStateHolder.formatTodayStudy(uiState.prefs.todayStudySeconds, strings.isBn)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedText.copy(alpha = dimAlpha * 0.85f)
                )
            }
            Text(
                text = strings.tapClockForZen,
                style = MaterialTheme.typography.labelSmall,
                color = MutedText.copy(alpha = dimAlpha * 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun LandscapeBottomControlStrip(
    uiState: StudyUiState,
    strings: StudyStrings,
    dimAlpha: Float,
    onOpenDuration: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenLaps: () -> Unit,
    onStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onReset: () -> Unit,
    onAdd15Min: () -> Unit,
    onRecordLap: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 1040.dp)
            .padding(top = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (uiState.activeMode == StudyMode.POMODORO) {
                CompactPillButton(
                    icon = Icons.Rounded.Schedule,
                    text = TimerStateHolder.formatDurationLabel(uiState.prefs.pomodoroDurationMinutes, strings.isBn),
                    dimAlpha = dimAlpha,
                    onClick = onOpenDuration,
                    testTag = "landscape_duration_pill"
                )
            } else {
                CompactPillButton(
                    icon = Icons.Rounded.Flag,
                    text = "${strings.laps}: ${uiState.timer.laps.size}",
                    dimAlpha = dimAlpha,
                    onClick = onOpenLaps,
                    testTag = "landscape_laps_pill"
                )
            }

            val intervalMin = uiState.prefs.activeVoiceIntervalMinutes
            val voiceOn = uiState.prefs.voiceEnabled && intervalMin > 0
            CompactPillButton(
                icon = if (voiceOn) Icons.Rounded.RecordVoiceOver else Icons.Rounded.VolumeOff,
                text = if (voiceOn) "${strings.everyPrefix} $intervalMin${strings.minutesUnit}" else strings.voiceOff,
                dimAlpha = dimAlpha,
                onClick = onOpenVoice,
                testTag = "landscape_voice_pill"
            )

            if (uiState.prefs.ultraBatteryMode) {
                Text(
                    text = strings.ecoBadge,
                    style = MaterialTheme.typography.labelSmall,
                    color = UltraEcoGreen.copy(alpha = dimAlpha),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .border(1.dp, UltraEcoGreen.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }

        PrimaryActionControlsRow(
            uiState = uiState,
            strings = strings,
            dimAlpha = dimAlpha,
            compact = true,
            onStartOrResume = onStartOrResume,
            onPause = onPause,
            onReset = onReset,
            onAdd15Min = onAdd15Min,
            onRecordLap = onRecordLap
        )
    }
}

@Composable
private fun PrimaryActionControlsRow(
    uiState: StudyUiState,
    strings: StudyStrings,
    dimAlpha: Float,
    compact: Boolean,
    onStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onReset: () -> Unit,
    onAdd15Min: () -> Unit,
    onRecordLap: () -> Unit
) {
    val status = uiState.timer.status
    val accent = MaterialTheme.colorScheme.primary
    val primaryHeight = if (compact) 48.dp else 62.dp
    val sideSize = if (compact) 48.dp else 56.dp

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 16.dp)
    ) {
        Surface(
            onClick = onReset,
            enabled = status != TimerStatus.IDLE,
            shape = CircleShape,
            color = ObsidianSurface,
            border = BorderStroke(
                1.dp,
                if (status != TimerStatus.IDLE) ObsidianBorder else ObsidianBorder.copy(alpha = 0.35f)
            ),
            modifier = Modifier
                .size(sideSize)
                .testTag("reset_button")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Rounded.Replay,
                    contentDescription = stringResource(R.string.cd_reset),
                    tint = if (status != TimerStatus.IDLE) {
                        SoftCreamText.copy(alpha = dimAlpha)
                    } else {
                        MutedText.copy(alpha = 0.3f)
                    },
                    modifier = Modifier.size(if (compact) 20.dp else 24.dp)
                )
            }
        }

        val isRunning = status == TimerStatus.RUNNING
        val primaryLabel = when (status) {
            TimerStatus.IDLE -> strings.start
            TimerStatus.RUNNING -> strings.pause
            TimerStatus.PAUSED -> strings.resume
            TimerStatus.COMPLETED -> strings.restart
        }
        val primaryIcon = when (status) {
            TimerStatus.RUNNING -> Icons.Rounded.Pause
            TimerStatus.COMPLETED -> Icons.Rounded.Refresh
            else -> Icons.Rounded.PlayArrow
        }

        Button(
            onClick = {
                if (isRunning) onPause() else onStartOrResume()
            },
            shape = RoundedCornerShape(999.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isRunning) ObsidianSurfaceHigh else accent.copy(alpha = dimAlpha),
                contentColor = if (isRunning) accent.copy(alpha = dimAlpha) else MaterialTheme.colorScheme.onPrimary
            ),
            border = if (isRunning) BorderStroke(1.5.dp, accent.copy(alpha = dimAlpha * 0.75f)) else null,
            contentPadding = PaddingValues(horizontal = if (compact) 22.dp else 36.dp),
            modifier = Modifier
                .height(primaryHeight)
                .widthIn(min = if (compact) 134.dp else 188.dp)
                .testTag("start_pause_button")
        ) {
            Icon(
                imageVector = primaryIcon,
                contentDescription = stringResource(R.string.cd_start_pause),
                modifier = Modifier.size(if (compact) 22.dp else 28.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = primaryLabel,
                style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge
            )
        }

        if (uiState.activeMode == StudyMode.POMODORO) {
            Surface(
                onClick = onAdd15Min,
                shape = CircleShape,
                color = ObsidianSurface,
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier
                    .size(sideSize)
                    .testTag("add_15_min_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = stringResource(R.string.cd_add_time),
                        tint = accent.copy(alpha = dimAlpha),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "15m",
                        style = MaterialTheme.typography.labelSmall,
                        color = SoftCreamText.copy(alpha = dimAlpha)
                    )
                }
            }
        } else {
            val lapEnabled = status == TimerStatus.RUNNING || status == TimerStatus.PAUSED
            Surface(
                onClick = onRecordLap,
                enabled = lapEnabled,
                shape = CircleShape,
                color = ObsidianSurface,
                border = BorderStroke(
                    1.dp,
                    if (lapEnabled) ObsidianBorder else ObsidianBorder.copy(alpha = 0.35f)
                ),
                modifier = Modifier
                    .size(sideSize)
                    .testTag("record_lap_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Flag,
                        contentDescription = stringResource(R.string.cd_lap),
                        tint = if (lapEnabled) accent.copy(alpha = dimAlpha) else MutedText.copy(alpha = 0.3f),
                        modifier = Modifier.size(if (compact) 20.dp else 22.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickConfigCard(
    icon: ImageVector,
    label: String,
    value: String,
    dimAlpha: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurface,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = modifier.height(66.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurfaceContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = dimAlpha),
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(verticalArrangement = Arrangement.Center) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedText.copy(alpha = dimAlpha * 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    color = SoftCreamText.copy(alpha = dimAlpha),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CompactPillButton(
    icon: ImageVector,
    text: String,
    dimAlpha: Float,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(999.dp),
        color = ObsidianSurface,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .height(48.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = dimAlpha),
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                color = SoftCreamText.copy(alpha = dimAlpha),
                maxLines = 1
            )
        }
    }
}

@Preview(name = "Landscape Eco Desk Clock", widthDp = 840, heightDp = 390, showBackground = true)
@Composable
private fun StudyScreenLandscapePreview() {
    NoctisFocusTheme(isStopwatchMode = false) {
        StudyScreen(
            uiState = StudyUiState(
                prefs = UserPreferences(pomodoroDurationMinutes = 120, pomodoroVoiceIntervalMinutes = 20),
                timer = TimerSnapshot(
                    mode = StudyMode.POMODORO,
                    status = TimerStatus.RUNNING,
                    targetDurationMs = 120 * 60_000L,
                    elapsedMs = 26 * 60_000L,
                    remainingMs = 94 * 60_000L,
                    voiceIntervalMinutes = 20,
                    voiceEnabled = true,
                    nextAnnouncementInMs = 14 * 60_000L
                )
            ),
            onRequestStartOrResume = {},
            onPause = {},
            onReset = {},
            onSelectMode = {},
            onAdd15Min = {},
            onRecordLap = {},
            onSetPomodoroDuration = {},
            onSetVoiceInterval = {},
            onSetVoiceEnabled = {},
            onSetVoiceLanguage = {},
            onSetChimeEnabled = {},
            onSetAnnounceRemaining = {},
            onTestVoice = {},
            onToggleUltraBatteryMode = {},
            onSetUltraBatteryMode = {},
            onSetOledTint = {},
            onSetAutoZenAfterStart = {},
            onSetDimMode = {},
            onSetDimBrightness = {},
            onSetKeepScreenOn = {},
            onSetShowSeconds = {},
            onSetOrientationLock = {},
            onToggleLandscapeQuick = {},
            onSetUiLanguage = {},
            onToggleZenMode = {},
            onEnterZenMode = {},
            onExitZenMode = {}
        )
    }
}
