package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AmoledPomodoroScheme = darkColorScheme(
    primary = WarmAmber,
    onPrimary = OnWarmAmber,
    primaryContainer = WarmAmberContainer,
    onPrimaryContainer = WarmAmber,
    secondary = CalmTeal,
    onSecondary = OnCalmTeal,
    secondaryContainer = CalmTealContainer,
    onSecondaryContainer = CalmTeal,
    tertiary = SoftCoral,
    onTertiary = Color(0xFF210704),
    tertiaryContainer = SoftCoralContainer,
    onTertiaryContainer = SoftCoral,
    background = AmoledBlack,
    onBackground = SoftCreamText,
    surface = ObsidianSurface,
    onSurface = SoftCreamText,
    surfaceVariant = ObsidianSurfaceContainer,
    onSurfaceVariant = MutedText,
    surfaceContainerLowest = AmoledBlack,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceContainer,
    surfaceContainerHigh = ObsidianSurfaceHigh,
    surfaceContainerHighest = Color(0xFF222632),
    outline = ObsidianBorder,
    outlineVariant = Color(0xFF1A1D26),
    error = SoftCoral,
    onError = Color(0xFF240705)
)

private val AmoledStopwatchScheme = AmoledPomodoroScheme.copy(
    primary = CalmTeal,
    onPrimary = OnCalmTeal,
    primaryContainer = CalmTealContainer,
    onPrimaryContainer = CalmTeal,
    secondary = WarmAmber,
    onSecondary = OnWarmAmber,
    secondaryContainer = WarmAmberContainer,
    onSecondaryContainer = WarmAmber
)

@Composable
fun NoctisFocusTheme(
    isStopwatchMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isStopwatchMode) AmoledStopwatchScheme else AmoledPomodoroScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = false
            insetsController.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
