package com.example.model

enum class StudyMode {
    POMODORO,
    STOPWATCH
}

enum class TimerStatus {
    IDLE,
    RUNNING,
    PAUSED,
    COMPLETED
}

enum class VoiceLanguage {
    BENGALI,
    ENGLISH
}

enum class UiLanguage {
    BENGALI,
    ENGLISH
}

enum class OrientationLock {
    AUTO,
    LANDSCAPE,
    PORTRAIT
}

enum class OledTint {
    LUMINOUS_WHITE,
    WARM_AMBER,
    ULTRA_ECO_RED
}

data class StudyLap(
    val index: Int,
    val totalElapsedMs: Long,
    val splitMs: Long
)

data class UserPreferences(
    val mode: StudyMode = StudyMode.POMODORO,
    val pomodoroDurationMinutes: Int = 120,
    val pomodoroVoiceIntervalMinutes: Int = 20,
    val stopwatchVoiceIntervalMinutes: Int = 20,
    val voiceEnabled: Boolean = true,
    val chimeEnabled: Boolean = true,
    val announceRemainingInPomodoro: Boolean = false,
    val voiceLanguage: VoiceLanguage = VoiceLanguage.BENGALI,
    val uiLanguage: UiLanguage = UiLanguage.BENGALI,
    val ultraBatteryMode: Boolean = true,
    val oledTint: OledTint = OledTint.WARM_AMBER,
    val autoZenAfterStart: Boolean = true,
    val keepScreenOn: Boolean = true,
    val dimModeEnabled: Boolean = true,
    val dimBrightness: Float = 0.20f,
    val showSeconds: Boolean = false,
    val orientationLock: OrientationLock = OrientationLock.AUTO,
    val todayStudySeconds: Long = 0L,
    val todayDateKey: String = ""
) {
    val activeVoiceIntervalMinutes: Int
        get() = when (mode) {
            StudyMode.POMODORO -> pomodoroVoiceIntervalMinutes
            StudyMode.STOPWATCH -> stopwatchVoiceIntervalMinutes
        }
}

data class TimerSnapshot(
    val mode: StudyMode = StudyMode.POMODORO,
    val status: TimerStatus = TimerStatus.IDLE,
    val targetDurationMs: Long = 120 * 60_000L,
    val elapsedMs: Long = 0L,
    val remainingMs: Long = 120 * 60_000L,
    val voiceIntervalMinutes: Int = 20,
    val voiceEnabled: Boolean = true,
    val lastAnnouncedStep: Int = 0,
    val nextAnnouncementInMs: Long? = null,
    val laps: List<StudyLap> = emptyList(),
    val lastAnnouncementText: String? = null
) {
    val displayTimeMs: Long
        get() = when (mode) {
            StudyMode.POMODORO -> remainingMs
            StudyMode.STOPWATCH -> elapsedMs
        }

    val progressFraction: Float
        get() = when (mode) {
            StudyMode.POMODORO -> {
                if (targetDurationMs <= 0L) 0f
                else (elapsedMs.toFloat() / targetDurationMs.toFloat()).coerceIn(0f, 1f)
            }
            StudyMode.STOPWATCH -> {
                val intervalMs = (voiceIntervalMinutes.coerceAtLeast(1) * 60_000L).toFloat()
                if (voiceEnabled && voiceIntervalMinutes > 0) {
                    ((elapsedMs % intervalMs.toLong()).toFloat() / intervalMs).coerceIn(0f, 1f)
                } else {
                    ((elapsedMs % 60_000L).toFloat() / 60_000f).coerceIn(0f, 1f)
                }
            }
        }
}
